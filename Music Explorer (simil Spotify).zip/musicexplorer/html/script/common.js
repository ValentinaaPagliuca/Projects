document.addEventListener('DOMContentLoaded', function () {
    checkServer();
    checkUser();
});

function checkServer() {
    fetch('http://localhost:3000/').then((response) => {
        if (response.ok) {
            return;
        }
        alert("Avviare il server!");
        window.location.reload();
    }).catch((error) => {
        alert("Avviare il server!");
        window.location.reload();
    });
}

function checkUser() {
    if (localStorage.getItem("user") === null) {
        window.location.href = "login.html";
    } else {
        var user = localStorage.getItem("user");
        user = JSON.parse(user);
        if(document.getElementById("username") !== null)
            document.getElementById("username").innerHTML = "<b>Utente: </b>" + user.username;
    }
}

function logout() {
    localStorage.removeItem("user");
    window.location.href = "login.html";
}


