const axios = require('axios');
const app = require('express').Router();

// Sostituisci con le tue credenziali Spotify API
const clientId = 'b0d10f8e043e4d99b37851235ba965df';
const clientSecret = '55ae9286cabb4ae785d18c7fbe945bbc';

// Funzione per ottenere il token di accesso da Spotify
async function getAccessToken() {
    const response = await axios.post(
        'https://accounts.spotify.com/api/token',
        'grant_type=client_credentials',
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            auth: {
                username: clientId,
                password: clientSecret,
            },
        }
    );

    return response.data.access_token;
}

// Funzione per cercare una canzone su Spotify
async function searchSongOnSpotify(songTitle) {
    const response = await axios.get(
        `https://api.spotify.com/v1/search?q=${encodeURIComponent(songTitle)}&type=track`,
        {
            headers: {
                Authorization: `Bearer ${await getAccessToken()}`,
            },
        }
    );
    return response.data.tracks.items;
}

// Cerco le top 10 globali su Spotify
async function getTop10() {
    const response = await axios.get(
        `https://api.spotify.com/v1/playlists/37i9dQZEVXbMDoHDwVN2tF/tracks`,
        {
            headers: {
                Authorization: `Bearer ${await getAccessToken()}`,
            },
        }
    );
    return response.data.items;
}

app.get('/search', async (req, res) => {
    const songTitle = req.query.title;
    const songs = await searchSongOnSpotify(songTitle);
    return res.json(songs);
});

app.get('/top/:howmany', async (req, res) => {
    const songs = await getTop10();
    return res.json(songs.slice(0, req.params.howmany));
});

module.exports = app;