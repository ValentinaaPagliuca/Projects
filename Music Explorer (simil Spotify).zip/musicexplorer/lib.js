const ObjectID = require('mongodb').ObjectId;

module.exports = {
isValidEmail: function isValidEmail(email) {
    const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    return isValid;
},

    isValidData: function isValidData(userData) {
        return userData !== null && userData !== undefined && userData !== "";
    },
    isValidArray: function isValidArray(userData) {
        return Array.isArray(userData) && userData.length > 0;
    },
    isValidMongoID: function isValidMongoID(id) {
        return ObjectID.isValid(id);
    },
    toMongoDBID: function toMongoDBID(id) {
        return new ObjectID(id);
    },
};