const lib = require("../lib");
const express = require("express").Router;
const app = express();
const crypto = require("crypto");

app.post('/login', async (req, res) => { // localhost:3000/login

    var email = req.body.email;
    var password = req.body.password;
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    if (!lib.isValidData(email) || !lib.isValidData(password)) {
        return res.status(400).json({error: "Email or password is empty!"});
    }
    

    var user = await global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .findOne({email: email, password: hashedPassword});
    if (user === null) {
        return res.status(400).json({error: "User not found!"});
    }

    return res.json({
        message: "Success!",
        user: user,
    });
});

app.post('/register', async (req, res) => {
    var nome = req.body.nome;
    var cognome = req.body.cognome;
    var email = req.body.email;
    var username = req.body.username;
    var password = req.body.password;
    if (password.length < 8 ) return res.status(400).json({error: "La Password deve essere minimo 8 caratteri!"});
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    
    var favourite_genre = req.body.artisti;
    var favourite_artist = req.body.generi;

    if(!lib.isValidEmail(email))
        return res.status(400).json({error: "Email non valida!"});
    if (!lib.isValidData(username) || !lib.isValidData(password) || !lib.isValidData(favourite_genre) || !lib.isValidData(favourite_artist)) {
        return res.status(400).json({error: "Inserisci tutti i campi"});
    }

    // find if email or username exists
    var user = await global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .findOne({$or: [{email: email}, {username: username}]});
    if (user !== null) {
        return res.status(400).json({error: "Email o username già esistente!"});
    }
    user = global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .insertOne({
            nome: nome,
            cognome: cognome,
            email: email,
            username: username,
            password: hashedPassword,
            favourite_genre: favourite_genre,
            favourite_artist: favourite_artist
        });
    if(user === null)
        return res.status(400).json({error: "Errore nella registrazione dell'utente!"});
    return res.status(200).json({message: "Registrato con successo!"});
});

module.exports = app;