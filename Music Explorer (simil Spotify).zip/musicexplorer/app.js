const express = require('express');
const mongoClient = require('mongodb').MongoClient;
const swaggerUi = require('swagger-ui-express');
 const swaggerDocument = require('./swagger-output.json');
const session = require('express-session');

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use(express.static('html'));
app.use(function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
})
app.use(session ({
    secret: 'musicexplorer',
    resave: false,
    saveUninitialized: true
}));

new mongoClient('mongodb+srv://pwm:5Xs563EdwXt0@pwm.zqpb92c.mongodb.net/?retryWrites=true&w=majority').connect().then((client) => {
    console.info("Database connected!");
    global.mongo = client;
}).catch((err) => {
    console.error("Database connection failed!");
    process.exit(1);
});

app.use('/documentazione', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.get('/', (req, res) => { // localhost:3000
    res.send('musicexplorer API');
});

const {auth} = require('./middleware/checkApiKey');
const path = require("path");

app.use('/', require('./autenticazione/auth')); // localhost:3000/
app.use('/utente', auth, require('./utente/utente'));
app.use('/spotifyapi', auth, require('./spotify'));




app.listen(port, () => {
    console.log(`App running at port ${port}`);
});