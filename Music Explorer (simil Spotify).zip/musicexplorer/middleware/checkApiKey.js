const apiKey = "123456"                                                       //api value
function auth(req, res, next) {
    if (req.query.apikey !== apiKey) {
      return res.status(401).json({ error: "chiave api non valida" })
    }
    return next();
}

module.exports = { auth }

//ogni richiesta in routes protette passa prima da questo. 