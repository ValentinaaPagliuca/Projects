const express = require('express');
const app = express.Router();
const lib = require("../lib");
const crypto = require("crypto");

app.get('/', (req, res) => {
    res.send('utente API');
});

app.post('/new_playlist', async (req, res) => {
    const name = req.body.name;
    let id = req.body.userid;
    const tags = req.body.tags;
    const public = req.body.public;

    if (!lib.isValidData(name) || !lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Enter all the fields!"});
    } else {
        id = lib.toMongoDBID(id);
    }

    var user = await global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .findOne({_id: id});
    if (user === null) {
        return res.status(400).json({error: "User not found!"});
    }
    global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .insertOne({
            name: name,
            userid: id,
            tags: tags,
            public: public,
        });
    return res.json({message: "Playlist creata!"});
});

app.get('/get_playlists', async (req, res) => {
    let id = req.query.userid;
    if (!lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Invalid ID!"});
    } else {
        id = lib.toMongoDBID(id);
    }
    var user = await global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .findOne({_id: id});
    if (user === null) {
        return res.status(400).json({error: "User not found!"});
    }
    var playlists = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .find({userid: id})
        .toArray();
    return res.json(playlists);
});

app.get('/mostra_playlist', async (req, res) => {
    let id = req.query.id;
    if (!lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Invalid ID!"});
    } else {
        id = lib.toMongoDBID(id);
    }
    var playlist = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .findOne({_id: id});
    if (playlist === null) {
        return res.status(400).json({error: "Playlist not found!"});
    }
    return res.json(playlist);
});

app.post('/modifica_playlist', async (req, res) => {
    const name = req.body.name;
    const tags = req.body.tags;
    let id = req.body.playlistid;
    const publicc = req.body.public === "true";

    if (!lib.isValidData(name) || !lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Enter all the fields!"});
    } else {
        id = lib.toMongoDBID(id);
    }
    var playlist = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .findOne({_id: id});
    if (playlist === null) {
        return res.status(400).json({error: "Playlist not found!"});
    }
    global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .updateOne({_id: id}, {
            $set: {
                name: name,
                tags: tags,
                public: publicc
            }
        });
    return res.json({message: "Playlist modificata!"});

});

app.delete('/elimina_playlist', async (req, res) => {
    let id = req.query.id;
    if (!lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Invalid ID!"});
    }
    id = lib.toMongoDBID(id);
    var playlist = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .findOne({_id: id});
    if (playlist === null) {
        return res.status(400).json({error: "Playlist not found!"});
    }
    global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .deleteOne({_id: id});
    return res.json({message: "Playlist eliminata!"});
});


app.delete('/elimina_song_from_playlist', async (req, res) => {
    var playlistid = req.query.playlistid;
    const name = req.query.name;

    if (!lib.isValidMongoID(playlistid) || !lib.isValidData(name)) {
        return res.status(400).json({error: "Enter all the fields!"});
    } else {
        playlistid = lib.toMongoDBID(playlistid);
    }
    var playlist = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .findOne({_id: playlistid});
    if (playlist === null) {
        return res.status(400).json({error: "Playlist not found!"});
    }
    global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .updateOne({_id: playlistid}, {
            $pull: {
                songs: {
                    name: name
                }
            }
        });
    return res.json({message: "Canzone eliminata dalla playlist!"});
});

app.post('/add_song_to_playlist', async (req, res) => {
    var playlistid = req.body.playlistid;
    const name = req.body.name;
    const artist = req.body.artist;
    const url = req.body.url;
    const image = req.body.image;

    if (!lib.isValidMongoID(playlistid) || !lib.isValidData(name) || !lib.isValidData(artist) || !lib.isValidData(url) || !lib.isValidData(image)) {
        return res.status(400).json({error: "Enter all the fields!"});
    } else {
        playlistid = lib.toMongoDBID(playlistid);
    }

    var playlist = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .findOne({_id: playlistid});
    if (playlist === null) {
        return res.status(400).json({error: "Playlist not found!"});
    }

    if(playlist.songs !== undefined) {
        for (var i = 0; i < playlist.songs.length; i++) {
            if (playlist.songs[i].url === url) {
                return res.status(400).json({error: "Canzone già presente nella playlist!"});
            }
        }
    }

    global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .updateOne({_id: playlistid}, {
            $push: {
                songs: {
                    name: name,
                    artist: artist,
                    url: url,
                    image: image
                }
            }
        });
    return res.json({message: "Canzone aggiunta alla playlist!"});
});

app.post('/change_info', async (req, res) => {
    const email = req.body.email;
    const username = req.body.username;
    const password = req.body.password;
    const favourite_genre = req.body.favourite_genre;
    const favourite_artist = req.body.favourite_artist;
    let id = req.body.id;

    if (!lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Invalid ID!"});
    } else {
        id = lib.toMongoDBID(id);
    }

    if (!lib.isValidData(email) || !lib.isValidData(username) || !lib.isValidData(password) || !lib.isValidData(favourite_genre) || !lib.isValidData(favourite_artist)) {
        return res.status(400).json({error: "Enter all the fields!"});
    }
    var user = await global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .findOne({_id: id});
    if (user === null) {
        return res.status(400).json({error: "User not found!"});
    }
    global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .updateOne({_id: id}, {
            $set: {
                email: email,
                username: username,
                password: password,
                favourite_genre: favourite_genre,
                favourite_artist: favourite_artist
            }
        });
    return res.json({message: "Utente aggiornato!"});
});

app.get('/get_others_playlists', async (req, res) => {
    let id = req.query.userid;
    if (!lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Invalid ID!"});
    } else {
        id = lib.toMongoDBID(id);
    }
    var user = await global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .findOne({_id: id});
    if (user === null) {
        return res.status(400).json({error: "User not found!"});
    }
    var playlists = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .find({
            userid: {$ne: id},
            public: true
        })
        .toArray();
    return res.json(playlists);
});

app.get("/dup_playlist", async (req, res) => {
    let id = req.query.id;
    if (!lib.isValidMongoID(id)) {
        return res.status(400).json({error: "Invalid ID!"});
    }
    id = lib.toMongoDBID(id);
    let playlistId = req.query.playlistId;
    if (!lib.isValidMongoID(playlistId)) {
        return res.status(400).json({error: "Invalid ID!"});
    }
    playlistId = lib.toMongoDBID(playlistId);
    var playlist = await global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .findOne({_id: playlistId});
    if (playlist === null) {
        return res.status(400).json({error: "Playlist not found!"});
    }
    var user = await global.mongo
        .db("musicexplorer")
        .collection("utenti")
        .findOne({_id: id});
    if (user === null) {
        return res.status(400).json({error: "User not found!"});
    }
    var newPlaylist = {
        name: playlist.name + " - Duplicata",
        userid: id,
        tags: playlist.tags,
        public: false,
        songs: playlist.songs
    };
    global.mongo
        .db("musicexplorer")
        .collection("playlist")
        .insertOne(newPlaylist);

    return res.redirect("/playlists.html");
});


app.get("/update-username", async (req, res) => {
    let id = req.query.id;
    let username = req.query.username;
    id = lib.toMongoDBID(id);

    global.mongo
    .db('musicexplorer')
    .collection('utenti')
    .updateOne(
        {_id: id},
        {$set: {username: username}}
    );

    res.json({message: "Username updated!"});
});



app.get("/update-password", async (req, res) => {
    
    let id = req.query.id;
    let password = req.query.password;
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    id = lib.toMongoDBID(id);

    global.mongo
    .db('musicexplorer')
    .collection('utenti')
    .updateOne(
        {_id: id},
        {$set: {password: hashedPassword}}
    );

    res.json({message: "Password updated!"});
}
);

    app.delete('/elimina_account', async (req, res) => {
        let id = req.query.id;
        if (!lib.isValidMongoID(id)) {
            return res.status(400).json({error: "Invalid ID!"});
        }
        id = lib.toMongoDBID(id);
        var user = await global.mongo
            .db("musicexplorer")
            .collection("utenti")
            .findOne({_id: id});
        if (user === null) {
            return res.status(400).json({error: "User not found!"});
        }
        global.mongo
            .db("musicexplorer")
            .collection("utenti")
            .deleteOne({_id: id});

            global.mongo
            .db("musicexplorer")
            .collection("playlist")
            .deleteMany({userid: id});
        
        return res.json({message: "Account eliminato!"});
    });


    
module.exports = app;