//
//  ColorExtensions.swift
//  Pulse
//
//  Created by Valentina Pagliuca on 21/02/26.
//

import SwiftUI

extension Color {

    static let pulseRed = Color.red
    static let surface = Color.black
    static let ghost = Color.gray.opacity(0.4)
    static let warmWhite = Color.white.opacity(0.9)

}
