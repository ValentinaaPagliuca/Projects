//
//  PulseCircle.swift
//  Pulse
//
//  Created by Valentina Pagliuca on 21/02/26.
//

import Foundation
import SwiftUI

// Visual representation of a single family member — the core UI element of the app
struct PulseCircle: View {
    let member: Member
    var size: CGFloat = 80

    // Animation state variables — all start inactive and get triggered on appear
    @State private var breathing = false
    @State private var glowing = false
    @State private var appeared = false

    // The ring color communicates the member's presence at a glance
    private var ringColor: Color {
        if member.sentToday { return .pulseRed }      // active today
        if member.daysMissing >= 2 { return .ghost }  // been a while
        return .surface                                // yesterday
    }

    var body: some View {
        VStack(spacing: 10) {
            ZStack {

                // Soft pulsing halo — only visible when the member has checked in today
                if member.sentToday {
                    Circle()
                        .fill(Color.pulseRed.opacity(0.08))
                        .frame(width: size + 28, height: size + 28)
                        .scaleEffect(glowing ? 1.08 : 0.95)
                        .blur(radius: 8)
                        .animation(
                            .easeInOut(duration: 2.2)
                            .repeatForever(autoreverses: true),
                            value: glowing
                        )
                }

                // Outer breathing ring — subtle, always present
                Circle()
                    .stroke(ringColor.opacity(0.3), lineWidth: 1)
                    .frame(width: size + 10, height: size + 10)
                    .scaleEffect(breathing ? 1.03 : 1.0)
                    .animation(
                        .easeInOut(duration: 3.0)
                        .repeatForever(autoreverses: true)
                        .delay(Double.random(in: 0...1)), // random delay so circles don't all breathe in sync
                        value: breathing
                    )

                // Inner ring — slightly thicker when the member is active today
                Circle()
                    .stroke(ringColor, lineWidth: member.sentToday ? 1.5 : 1)
                    .frame(width: size, height: size)
                    .scaleEffect(breathing ? 1.02 : 1.0)
                    .animation(
                        .easeInOut(duration: 2.5)
                        .repeatForever(autoreverses: true),
                        value: breathing
                    )

                // Core dot — glows red when active, fades to ghost when silent
                Circle()
                    .fill(member.sentToday ? Color.pulseRed : Color.ghost)
                    .frame(width: size * 0.13, height: size * 0.13)
                    .shadow(
                        color: member.sentToday ? Color.pulseRed.opacity(0.9) : .clear,
                        radius: glowing ? 10 : 4
                    )
                    .scaleEffect(glowing ? 1.3 : 1.0)
                    .animation(
                        .easeInOut(duration: 1.4)
                        .repeatForever(autoreverses: true),
                        value: glowing
                    )

                // Emoji — fades out when the member has been silent for 2+ days
                Text(member.emoji)
                    .font(.system(size: size * 0.38))
                    .opacity(member.daysMissing >= 2 ? 0.25 : 1.0)
                    .scaleEffect(appeared ? 1.0 : 0.5)
                    .animation(.spring(response: 0.5, dampingFraction: 0.6), value: appeared)
            }
            // Entrance animation — the whole circle scales up from nothing
            .scaleEffect(appeared ? 1.0 : 0.3)
            .opacity(appeared ? 1.0 : 0)

            // Name label
            Text(member.name)
                .font(.system(size: 11, weight: .light, design: .monospaced))
                .foregroundColor(member.daysMissing >= 2 ? .gray.opacity(0.3) : .warmWhite)
                .tracking(1.5)
                .opacity(appeared ? 1.0 : 0)

            // Status line — three states: active today, silent for days, or just yesterday
            Group {
                if member.sentToday {
                    Text("here today")
                        .foregroundColor(.pulseRed.opacity(0.8))
                } else if member.daysMissing >= 2 {
                    Text("\(member.daysMissing)d silent")
                        .foregroundColor(.gray.opacity(0.3))
                } else {
                    Text("yesterday")
                        .foregroundColor(.gray.opacity(0.5))
                }
            }
            .font(.system(size: 8, weight: .light, design: .monospaced))
            .tracking(1)
            .opacity(appeared ? 1.0 : 0)
        }
        .onAppear {
            // entrance spring, then start the breathing and glow loops slightly after
            withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                appeared = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                breathing = true
                glowing = true
            }
        }
    }
}
