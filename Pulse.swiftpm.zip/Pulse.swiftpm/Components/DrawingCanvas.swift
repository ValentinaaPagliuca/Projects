import Foundation
import SwiftUI

// Represents a single stroke drawn by the user, storing its points, color, and width
struct DrawingLine: Identifiable {
    let id = UUID()
    var points: [CGPoint]
    var color: Color
    var lineWidth: CGFloat
}

struct DrawingCanvas: View {
    @Binding var lines: [DrawingLine]           // all completed strokes
    @State private var currentLine: DrawingLine? // the stroke currently being drawn

    var body: some View {
        Canvas { context, size in
            // draw all the strokes that have already been completed
            for line in lines {
                var path = Path()
                guard let first = line.points.first else { continue }
                path.move(to: first)
                for point in line.points.dropFirst() {
                    path.addLine(to: point)
                }
                context.stroke(path, with: .color(line.color),
                               style: StrokeStyle(lineWidth: line.lineWidth, lineCap: .round, lineJoin: .round))
            }

            // also draw the in-progress stroke so the user sees it in real time
            if let current = currentLine {
                var path = Path()
                guard let first = current.points.first else { return }
                path.move(to: first)
                for point in current.points.dropFirst() {
                    path.addLine(to: point)
                }
                context.stroke(path, with: .color(current.color),
                               style: StrokeStyle(lineWidth: current.lineWidth, lineCap: .round, lineJoin: .round))
            }
        }
        .gesture(
            DragGesture(minimumDistance: 0, coordinateSpace: .local)
                .onChanged { value in
                    let point = value.location

                    // compute gesture speed as the magnitude of the velocity vector
                    let velocity = sqrt(
                        pow(value.velocity.width, 2) +
                        pow(value.velocity.height, 2)
                    )

                    // color and width react to speed — faster strokes become thinner and redder
                    let strokeColor = colorForVelocity(velocity)
                    let strokeWidth = widthForVelocity(velocity)

                    if currentLine == nil {
                        // first point of a new stroke
                        currentLine = DrawingLine(points: [point], color: strokeColor, lineWidth: strokeWidth)
                    } else {
                        currentLine?.points.append(point)
                        currentLine?.color = strokeColor
                        currentLine?.lineWidth = strokeWidth
                    }
                }
                .onEnded { _ in
                    // finger lifted — save the stroke and reset
                    if let line = currentLine {
                        lines.append(line)
                    }
                    currentLine = nil
                }
        )
    }

    // slow strokes → dark and thick, like a heavy mark
    func colorForVelocity(_ velocity: CGFloat) -> Color {
        switch velocity {
        case 0..<300:   return .gray
        case 300..<600: return .gray.opacity(0.7)
        case 600..<900: return .red.opacity(0.7)
        default:        return .red
        }
    }

    // fast strokes → thin and sharp, almost like a scream
    func widthForVelocity(_ velocity: CGFloat) -> CGFloat {
        switch velocity {
        case 0..<300:   return 6
        case 300..<600: return 4
        case 600..<900: return 3
        default:        return 2
        }
    }
}
