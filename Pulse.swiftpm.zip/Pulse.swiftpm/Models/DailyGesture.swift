//
//  DailyGesture.swift
//  Pulse
//
//  Created by Valentina Pagliuca on 21/02/26.
//

import Foundation
import SwiftUI

/// Determines which type of pulse gesture the user should send today.
/// The gesture rotates daily so each day feels intentionally different.
struct DailyGesture {

    /// Returns the `PulseType` assigned to today by cycling through all available types
    /// using the day-of-year as an index. This way every user in the same group
    /// sees the same prompt on the same day.
    /// - Returns: The `PulseType` for today.
    static func gestureForToday() -> PulseType {
        let allTypes = PulseType.allCases
        // ordinality gives us a 1-based day index (1–365), mod maps it into the array
        let dayOfYear = Calendar.current.ordinality(of: .day, in: .year, for: Date()) ?? 0
        return allTypes[dayOfYear % allTypes.count]
    }
}
