
import SwiftUI

/// A single person in a Pulse group.
/// Conforms to `Codable` for future persistence and `Identifiable` for SwiftUI lists.
struct Member: Identifiable, Codable {

    /// Unique identifier for this member.
    var id: UUID = UUID()

    /// Display name shown under the circle (e.g. "Mum", "Dad").
    var name: String

    /// Emoji chosen to represent this member visually.
    var emoji: String

    /// Full history of pulses this member has sent, in insertion order.
    var pulses: [PulseEntry]

    /// The date of the most recent pulse, or `nil` if the member has never sent one.
    /// Sorts descending so the first element is always the latest.
    var lastPulseDate: Date? {
        pulses.sorted { $0.date > $1.date }.first?.date
    }

    /// `true` if the member has sent at least one pulse today.
    var sentToday: Bool {
        guard let last = lastPulseDate else { return false }
        return Calendar.current.isDateInToday(last)
    }

    /// Number of days since the member's last pulse.
    /// Returns 99 if the member has never sent a pulse, so the UI can treat them as long-silent.
    var daysMissing: Int {
        guard let last = lastPulseDate else { return 99 }
        return Calendar.current.dateComponents([.day], from: last, to: Date()).day ?? 0
    }
}
