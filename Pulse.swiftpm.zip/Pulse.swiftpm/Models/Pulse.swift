//
//  Pulse.swift
//  Pulse
//

import Foundation
import SwiftUI

/// The four types of daily gesture a user can send.
/// `CaseIterable` allows `DailyGesture` to rotate through them by index.
/// `Codable` enables future persistence of entries that reference this type.
enum PulseType: String, Codable, CaseIterable {
    case photo       = "Photo"
    case draw        = "Draw"
    case temperature = "Temperature"
    case silence     = "Silence"

    /// Emoji icon representing this pulse type in the UI.
    var emoji: String {
        switch self {
        case .photo:       return "📷"
        case .draw:        return "✏️"
        case .temperature: return "🌡️"
        case .silence:     return "🔇"
        }
    }

    /// Short prompt shown to the user when this type is the daily gesture.
    var prompt: String {
        switch self {
        case .photo:       return "Show us exactly where you are right now."
        case .draw:        return "Draw how you feel right now."
        case .temperature: return "How hot or cold does today feel?"
        case .silence:     return "No words. Just let them know you're here."
        }
    }
}

/// A single gesture sent by a member on a given day.
/// Only the fields relevant to the pulse type will be populated —
/// e.g. `temperature` is set for `.temperature`, `drawingData` for `.draw`, and so on.
struct PulseEntry: Identifiable, Codable {

    /// Unique identifier for this entry.
    var id: UUID = UUID()

    /// The date and time the pulse was sent.
    var date: Date

    /// The type of gesture this entry represents.
    var type: PulseType

    /// A 0–1 value representing emotional warmth, used only for `.temperature` pulses.
    var temperature: Double?

    /// Raw drawing data captured from the canvas, used only for `.draw` pulses.
    var drawingData: Data?

    /// JPEG/PNG image data captured from the camera, used only for `.photo` pulses.
    var photoData: Data?
}
