//
//  Group.swift
//  Pulse
//
//  Created by Valentina Pagliuca on 21/02/26.
//

import Foundation
import SwiftUI

/// A group of people sharing daily pulses together — the core social unit of the app.
/// Conforms to `Codable` for future persistence and `Identifiable` for use in SwiftUI lists.
struct PulseGroup: Identifiable, Codable {

    /// Unique identifier for this group.
    var id: UUID = UUID()

    /// Display name of the group (e.g. "Family", "Friends").
    var name: String

    /// Short invite code others can use to join this group.
    var code: String

    /// All members currently in the group, including the local user.
    var members: [Member]

    /// Generates a random 6-character invite code using an unambiguous character set
    /// (no I, O, 0, 1 to avoid confusion when reading aloud or typing).
    /// - Returns: A 6-character uppercase alphanumeric string.
    static func generateCode() -> String {
        let letters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return String((0..<6).map { _ in letters.randomElement()! })
    }
}
