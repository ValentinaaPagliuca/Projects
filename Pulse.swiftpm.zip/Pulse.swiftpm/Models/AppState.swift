//
//  AppState.swift
//  Pulse
//

import Foundation
import Combine
import SwiftUI

/// Central state container for the entire Pulse app.
/// Conforms to `ObservableObject` so SwiftUI views automatically
/// re-render when any `@Published` property changes.
@MainActor
class AppState: ObservableObject {

    /// The local user — the person holding this device.
    @Published var currentUser: Member

    /// The currently active group shown in the main view.
    @Published var group: PulseGroup

    /// All groups the user belongs to (supports multi-group in the future).
    @Published var allGroups: [PulseGroup]

    /// Whether the user has completed onboarding.
    @Published var hasOnboarded: Bool

    /// Seeds the app with a demo Family group so reviewers see a meaningful UI immediately.
    init() {
        let me = Member(name: "You", emoji: "💫", pulses: [])

        let familyGroup = PulseGroup(
            name: "Family",
            code: PulseGroup.generateCode(),
            members: [
                me,
                Member(name: "Mum", emoji: "🌸", pulses: [
                    PulseEntry(date: Date(), type: .silence),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .temperature, temperature: 0.6),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .draw),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .photo),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, type: .silence),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -5, to: Date())!, type: .temperature, temperature: 0.3),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -6, to: Date())!, type: .draw)
                ]),
                Member(name: "Dad", emoji: "🌊", pulses: [
                    PulseEntry(date: Date(), type: .temperature, temperature: 0.7),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .silence),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .photo),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .temperature, temperature: 0.4),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, type: .draw)
                ]),
                Member(name: "Sis", emoji: "⚡", pulses: [
                    PulseEntry(date: Date(), type: .draw),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .photo),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .temperature, temperature: 0.8),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .silence),
                    PulseEntry(date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, type: .draw)
                ])
            ]
        )

        self.currentUser = me
        self.group = familyGroup
        self.allGroups = [familyGroup]
        self.hasOnboarded = false
    }

    /// Switches the active group and updates `currentUser` to the matching member inside it.
    /// - Parameter newGroup: The group to switch to.
    func switchToGroup(_ newGroup: PulseGroup) {
        group = newGroup
        // re-sync currentUser to the instance that lives inside the new group
        if let me = newGroup.members.first(where: { $0.id == currentUser.id || $0.name == currentUser.name }) {
            currentUser = me
        }
    }

    /// Appends a new pulse entry for the current user and propagates the change
    /// up through `group` and `allGroups` so every view stays in sync.
    /// - Parameter entry: The `PulseEntry` to record (temperature, draw, photo, or silence).
    func sendPulseEntry(_ entry: PulseEntry) {
        guard let myIndex = group.members.firstIndex(where: { $0.id == currentUser.id || $0.name == currentUser.name }) else { return }

        group.members[myIndex].pulses.append(entry)
        currentUser = group.members[myIndex]

        // mirror the updated group into allGroups so the group picker stays consistent
        if let groupIndex = allGroups.firstIndex(where: { $0.id == group.id }) {
            allGroups[groupIndex] = group
        }
    }
}
