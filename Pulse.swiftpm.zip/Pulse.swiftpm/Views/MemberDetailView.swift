import Foundation
import SwiftUI

/// A sheet showing a single member's profile and their full pulse history,
/// displayed as a scrollable list of `PulseRow` cells.
struct MemberDetailView: View {
    let member: Member
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {

                // HEADER — dismiss button
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .light))
                            .foregroundColor(.gray.opacity(0.9))
                    }
                    Spacer()
                }
                .padding(.horizontal, 28)
                .padding(.top, 28)
                .padding(.bottom, 32)

                // PROFILE — concentric rings mirror the PulseCircle aesthetic
                VStack(spacing: 16) {
                    ZStack {
                        Circle()
                            .stroke(member.sentToday ? Color.pulseRed.opacity(0.3) : Color.surface, lineWidth: 1)
                            .frame(width: 100, height: 100)
                        Circle()
                            .stroke(member.sentToday ? Color.pulseRed.opacity(0.6) : Color.ghost, lineWidth: 1)
                            .frame(width: 70, height: 70)
                        Text(member.emoji)
                            .font(.system(size: 36))
                    }

                    Text(member.name)
                        .font(.custom("Georgia", size: 28))
                        .fontWeight(.light)
                        .foregroundColor(.warmWhite)
                        .tracking(3)

                    // Status label — three states matching PulseCircle logic
                    if member.sentToday {
                        Text("here today")
                            .font(.system(size: 15, weight: .light, design: .monospaced))
                            .foregroundColor(.pulseRed)
                            .tracking(3)
                    } else if member.daysMissing >= 2 {
                        Text("silent for \(member.daysMissing) days")
                            .font(.system(size: 12, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.9))
                            .tracking(3)
                    } else {
                        Text("last seen yesterday")
                            .font(.system(size: 15, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.9))
                            .tracking(3)
                    }
                }
                .padding(.bottom, 40)

                Rectangle()
                    .fill(Color.surface)
                    .frame(height: 1)
                    .padding(.horizontal, 28)
                    .padding(.bottom, 32)

                // PULSE HISTORY — sorted newest first
                Text("recent pulses")
                    .font(.system(size: 12, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(3)
                    .padding(.bottom, 20)

                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(member.pulses.sorted { $0.date > $1.date }) { pulse in
                            PulseRow(pulse: pulse)
                        }
                    }
                    .padding(.horizontal, 28)
                }
            }
        }
    }
}

/// A single row in the pulse history list, showing the date, type, and content of one entry.
struct PulseRow: View {
    let pulse: PulseEntry

    var body: some View {
        HStack(spacing: 16) {

            // Date column — day number above abbreviated month
            VStack(spacing: 2) {
                Text(pulse.date, format: .dateTime.day())
                    .font(.custom("Georgia", size: 22))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                Text(pulse.date, format: .dateTime.month(.abbreviated))
                    .font(.system(size: 11, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(1)
            }
            .frame(width: 40)

            // Vertical timeline line
            Rectangle()
                .fill(Color.surface)
                .frame(width: 1)
                .frame(maxHeight: .infinity)

            // Pulse type + content
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 8) {
                    Text(pulse.type.emoji)
                        .font(.system(size: 16))
                    Text(pulse.type.rawValue.uppercased())
                        .font(.system(size: 8, weight: .light, design: .monospaced))
                        .foregroundColor(.pulseRed)
                        .tracking(2)
                }

                pulseContent
            }

            Spacer()
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 2)
                .stroke(Color.surface, lineWidth: 1)
        )
    }

    /// Renders the appropriate content for each pulse type.
    /// Photo and drawing data are stored as `Data` blobs; temperature maps to a descriptive label.
    @ViewBuilder
    var pulseContent: some View {
        switch pulse.type {

        case .photo:
            if let data = pulse.photoData, let uiImage = UIImage(data: data) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 120)
                    .clipShape(RoundedRectangle(cornerRadius: 2))
            } else {
                // Fallback for demo data that has no actual image attached
                Text("📷 photo")
                    .font(.system(size: 11, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .italic()
            }

        case .draw:
            // Drawing rendering is a future enhancement — placeholder for now
            Text("✏️ drawing")
                .font(.system(size: 11, weight: .light, design: .monospaced))
                .foregroundColor(.gray.opacity(0.9))
                .italic()

        case .temperature:
            if let temp = pulse.temperature {
                Text(temperatureLabel(for: temp))
                    .font(.system(size: 13, weight: .light, design: .monospaced))
                    .foregroundColor(temp < 0.5 ? .blue : .red)
            }

        case .silence:
            Text("just here")
                .font(.system(size: 11, weight: .light, design: .monospaced))
                .foregroundColor(.gray.opacity(0.9))
                .italic()
        }
    }

    /// Maps a 0–1 temperature value to a human-readable emoji label.
    /// - Parameter value: The normalized temperature from the pulse entry.
    /// - Returns: A descriptive string like "🔥 burning" or "❄️ freezing".
    func temperatureLabel(for value: Double) -> String {
        switch value {
        case 0..<0.2: return "❄️ freezing"
        case 0.2..<0.4: return "🌬️ cold"
        case 0.4..<0.6: return "😌 neutral"
        case 0.6..<0.8: return "🌤️ warm"
        default:        return "🔥 burning"
        }
    }
}
