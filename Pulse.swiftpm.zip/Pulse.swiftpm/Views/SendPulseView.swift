import Foundation
import SwiftUI
import PhotosUI

/// The sheet where the user composes and sends their daily pulse.
/// Pre-selects today's gesture type from `DailyGesture`, but lets the user switch freely.
struct SendPulseView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    /// The pulse type currently selected in the picker — defaults to today's assigned gesture.
    @State private var selectedType: PulseType = DailyGesture.gestureForToday()

    /// The normalized 0–1 temperature value, used only for the `.temperature` type.
    @State private var temperature: Double = 0.5

    /// When `true`, the success overlay fades in and the sheet auto-dismisses after 2 seconds.
    @State private var showSuccess = false

    /// The strokes drawn by the user on the canvas, used only for the `.draw` type.
    @State private var drawingLines: [DrawingLine] = []

    /// The photo item selected from the system Photos picker.
    @State private var selectedPhotoItem: PhotosPickerItem? = nil

    /// The raw image data loaded from `selectedPhotoItem`, stored in the pulse entry on send.
    @State private var selectedPhotoData: Data? = nil

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {

                // HEADER — invisible xmark on the right keeps the title centered
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(.gray.opacity(0.9))
                    }
                    Spacer()
                    Text("today's pulse")
                        .font(.system(size: 12, weight: .light, design: .monospaced))
                        .foregroundColor(.gray.opacity(0.9))
                        .tracking(3)
                    Spacer()
                    Image(systemName: "xmark")
                        .font(.system(size: 14))
                        .foregroundColor(.clear)
                }
                .padding(.horizontal, 28)
                .padding(.top, 28)
                .padding(.bottom, 32)

                // GESTURE PICKER — horizontal scroll of all pulse types
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(PulseType.allCases, id: \.self) { type in
                            VStack(spacing: 6) {
                                Text(type.emoji)
                                    .font(.system(size: 22))
                                Text(type.rawValue)
                                    .font(.system(size: 8, weight: .light, design: .monospaced))
                                    .foregroundColor(selectedType == type ? .pulseRed : .gray.opacity(0.9))
                                    .tracking(1)
                            }
                            .padding(.vertical, 12)
                            .padding(.horizontal, 14)
                            .background(
                                RoundedRectangle(cornerRadius: 2)
                                    .stroke(selectedType == type ? Color.pulseRed : Color.surface, lineWidth: 1)
                            )
                            .onTapGesture {
                                withAnimation(.spring(response: 0.3)) {
                                    selectedType = type
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 28)
                }

                // PROMPT — updates with a cross-fade whenever the selected type changes
                Text(selectedType.prompt)
                    .font(.custom("Georgia", size: 20))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                    .multilineTextAlignment(.center)
                    .tracking(1)
                    .padding(.horizontal, 36)
                    .padding(.vertical, 36)
                    .animation(.easeInOut, value: selectedType)

                // INPUT AREA — renders a different UI for each pulse type
                inputArea
                    .padding(.horizontal, 28)

                Spacer()

                // SEND BUTTON
                Button {
                    sendPulse()
                } label: {
                    HStack(spacing: 12) {
                        Circle()
                            .fill(Color.pulseRed)
                            .frame(width: 6, height: 6)
                            .shadow(color: .pulseRed, radius: 4)
                        Text("send pulse")
                            .font(.system(size: 11, weight: .light, design: .monospaced))
                            .foregroundColor(.warmWhite)
                            .tracking(3)
                    }
                    .padding(.vertical, 20)
                    .padding(.horizontal, 48)
                    .background(
                        RoundedRectangle(cornerRadius: 2)
                            .stroke(Color.pulseRed.opacity(0.5), lineWidth: 1)
                    )
                }
                .padding(.bottom, 48)
            }

            // SUCCESS OVERLAY — fades in on top of everything after sending
            if showSuccess {
                successOverlay
            }
        }
    }

    // MARK: - Input Area

    /// Renders the appropriate input UI based on the currently selected pulse type.
    @ViewBuilder
    var inputArea: some View {
        switch selectedType {

        case .photo:
            VStack(spacing: 16) {
                // Show the selected image, or a picker placeholder if none chosen yet
                if let data = selectedPhotoData, let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity)
                        .frame(height: 240)
                        .clipShape(RoundedRectangle(cornerRadius: 2))
                        .overlay(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(Color.surface, lineWidth: 1)
                        )
                } else {
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        VStack(spacing: 12) {
                            Text("📷")
                                .font(.system(size: 48))
                            Text("tap to choose a photo")
                                .font(.system(size: 10, weight: .light, design: .monospaced))
                                .foregroundColor(.gray.opacity(0.9))
                                .tracking(2)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 240)
                        .background(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(Color.surface, lineWidth: 1)
                        )
                    }
                }

                // "Change photo" link — only shown once a photo is already selected
                if selectedPhotoData != nil {
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        Text("change photo")
                            .font(.system(size: 9, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.5))
                            .tracking(2)
                    }
                }
            }
            // Load the raw Data from the PhotosPickerItem asynchronously
            .onChange(of: selectedPhotoItem) { newItem in
                Task {
                    if let data = try? await newItem?.loadTransferable(type: Data.self) {
                        selectedPhotoData = data
                    }
                }
            }

        case .draw:
            VStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.gray.opacity(0.15))
                        .frame(height: 220)
                        .overlay(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(Color.surface, lineWidth: 1)
                        )

                    // Placeholder hint — disappears once the user starts drawing
                    if drawingLines.isEmpty {
                        VStack(spacing: 8) {
                            Text("✏️")
                                .font(.system(size: 32))
                            Text("draw with your finger")
                                .font(.system(size: 10, weight: .light, design: .monospaced))
                                .foregroundColor(.gray.opacity(0.9))
                                .tracking(2)
                        }
                    }

                    // The velocity-sensitive drawing canvas
                    DrawingCanvas(lines: $drawingLines)
                        .frame(height: 220)
                        .clipShape(RoundedRectangle(cornerRadius: 2))
                }

                // Speed-to-color legend so the user understands the visual encoding
                HStack(spacing: 16) {
                    ForEach([
                        ("slow", Color.blue),
                        ("medium", Color.green),
                        ("fast", Color.orange),
                        ("very fast", Color.red)
                    ], id: \.0) { label, color in
                        HStack(spacing: 4) {
                            Circle().fill(color).frame(width: 6, height: 6)
                            Text(label)
                                .font(.system(size: 7, design: .monospaced))
                                .foregroundColor(.gray.opacity(0.7))
                        }
                    }
                }

                Button {
                    drawingLines.removeAll()
                } label: {
                    Text("clear canvas")
                        .font(.system(size: 9, weight: .light, design: .monospaced))
                        .foregroundColor(.gray.opacity(0.5))
                        .tracking(2)
                }
            }

        case .temperature:
            VStack(spacing: 20) {
                // Live emoji label that reacts to the slider position
                Text(temperatureLabel)
                    .font(.custom("Georgia", size: 36))
                    .foregroundColor(temperatureColor)
                    .animation(.easeInOut, value: temperature)

                Slider(value: $temperature, in: 0...1)
                    .tint(.pulseRed)

                HStack {
                    Text("freezing")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(.gray.opacity(0.9))
                        .tracking(1)
                    Spacer()
                    Text("burning")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(.gray.opacity(0.9))
                        .tracking(1)
                }
            }

        case .silence:
            // No input needed — just a confirmation that showing up is enough
            VStack(spacing: 12) {
                Text("🔇")
                    .font(.system(size: 48))
                Text("your presence is enough")
                    .font(.system(size: 11, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(2)
            }
            .frame(maxWidth: .infinity)
            .padding(32)
            .background(
                RoundedRectangle(cornerRadius: 2)
                    .stroke(Color.surface, lineWidth: 1)
            )
        }
    }

    // MARK: - Success Overlay

    /// Full-screen confirmation shown after a pulse is successfully sent.
    /// Auto-dismisses the sheet after 2 seconds.
    var successOverlay: some View {
        ZStack {
            Color.black.opacity(0.95).ignoresSafeArea()
            VStack(spacing: 24) {
                // Concentric rings with a glowing core — mirrors the app's visual language
                ZStack {
                    Circle()
                        .stroke(Color.pulseRed.opacity(0.2), lineWidth: 1)
                        .frame(width: 120, height: 120)
                    Circle()
                        .stroke(Color.pulseRed.opacity(0.5), lineWidth: 1)
                        .frame(width: 80, height: 80)
                    Circle()
                        .fill(Color.pulseRed)
                        .frame(width: 16, height: 16)
                        .shadow(color: .pulseRed, radius: 12)
                }

                Text("pulse sent")
                    .font(.custom("Georgia", size: 32))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                    .tracking(4)

                Text("your circle knows you're here")
                    .font(.system(size: 10, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(2)
            }
        }
        .transition(.opacity)
    }

    // MARK: - Helpers

    /// Maps the current slider value to a descriptive emoji label.
    var temperatureLabel: String {
        switch temperature {
        case 0..<0.2: return "❄️ freezing"
        case 0.2..<0.4: return "🌬️ cold"
        case 0.4..<0.6: return "😌 neutral"
        case 0.6..<0.8: return "🌤️ warm"
        default:        return "🔥 burning"
        }
    }

    /// The slider label color — blue for cold values, red for warm ones.
    var temperatureColor: Color {
        temperature < 0.5 ? .blue : .red
    }

    /// Builds a `PulseEntry` from the current input state, saves it via `AppState`,
    /// shows the success overlay, and dismisses the sheet after a short delay.
    func sendPulse() {
        let entry = PulseEntry(
            date: Date(),
            type: selectedType,
            temperature: selectedType == .temperature ? temperature : nil,
            drawingData: nil, // drawing serialization is a future enhancement
            photoData: selectedPhotoData
        )

        appState.sendPulseEntry(entry)

        withAnimation(.easeInOut(duration: 0.4)) {
            showSuccess = true
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            dismiss()
        }
    }
}
