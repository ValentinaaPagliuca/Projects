import Foundation
import SwiftUI

/// A 30-day history view showing which days the current user sent a pulse.
/// Each day cell displays the pulse type emoji if one was sent, or the day number if not.
struct CalendarView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    /// 7-column grid — one column per day of the week.
    let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 7)

    /// Maps each calendar day (normalized to midnight) to the pulse sent on that day.
    /// If the user sent multiple pulses in one day, only the last one is kept.
    var last30Pulses: [Date: PulseEntry] {
        var dict: [Date: PulseEntry] = [:]
        for pulse in appState.currentUser.pulses {
            let day = Calendar.current.startOfDay(for: pulse.date)
            dict[day] = pulse
        }
        return dict
    }

    /// The last 30 days in chronological order (oldest → today).
    var last30Days: [Date] {
        (0..<30).compactMap {
            Calendar.current.date(byAdding: .day, value: -$0, to: Date())
        }.reversed()
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {

                // HEADER — dismiss button centered with an invisible spacer on the right for balance
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(.gray)
                    }
                    Spacer()
                    Text("your history")
                        .font(.system(size: 13, weight: .light, design: .monospaced))
                        .foregroundColor(.white.opacity(0.7))
                        .tracking(3)
                    Spacer()
                    // Invisible xmark keeps the title visually centered
                    Image(systemName: "xmark")
                        .foregroundColor(.clear)
                        .font(.system(size: 14))
                }
                .padding(.horizontal, 28)
                .padding(.top, 28)
                .padding(.bottom, 40)

                // PROFILE — emoji, name, and total pulse count
                VStack(spacing: 12) {
                    Text(appState.currentUser.emoji)
                        .font(.system(size: 48))
                    Text(appState.currentUser.name)
                        .font(.custom("Georgia", size: 24))
                        .fontWeight(.light)
                        .foregroundColor(.white)
                        .tracking(3)

                    Text("\(appState.currentUser.pulses.count) pulses sent")
                        .font(.system(size: 12, weight: .light, design: .monospaced))
                        .foregroundColor(.pulseRed)
                        .tracking(2)
                }
                .padding(.bottom, 40)

                // CALENDAR GRID
                VStack(spacing: 0) {

                    // Weekday letter headers
                    HStack(spacing: 0) {
                        ForEach(["M","T","W","T","F","S","S"], id: \.self) { d in
                            Text(d)
                                .font(.system(size: 12, weight: .medium, design: .monospaced))
                                .foregroundColor(.white.opacity(0.6))
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .padding(.horizontal, 28)
                    .padding(.bottom, 12)

                    // Divider between headers and grid
                    Rectangle()
                        .fill(Color.white.opacity(0.15))
                        .frame(height: 1)
                        .padding(.horizontal, 28)
                        .padding(.bottom, 16)

                    // Day cells — red-tinted if a pulse was sent, dim otherwise
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(last30Days, id: \.self) { day in
                            let pulse = last30Pulses[Calendar.current.startOfDay(for: day)]
                            let isToday = Calendar.current.isDateInToday(day)

                            ZStack {
                                // Background circle — highlighted if a pulse exists
                                Circle()
                                    .fill(pulse != nil ? Color.pulseRed.opacity(0.25) : Color.white.opacity(0.06))
                                    .frame(width: 36, height: 36)

                                // Red ring marks today's cell
                                if isToday {
                                    Circle()
                                        .stroke(Color.pulseRed, lineWidth: 1)
                                        .frame(width: 36, height: 36)
                                }

                                // Show the pulse type emoji, or the day number if no pulse was sent
                                if let pulse = pulse {
                                    Text(pulse.type.emoji)
                                        .font(.system(size: 14))
                                } else {
                                    Text(dayNumber(day))
                                        .font(.system(size: 12, weight: .regular, design: .monospaced))
                                        .foregroundColor(.white.opacity(0.5))
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 28)
                }

                Spacer()

                // LEGEND — explains the two possible cell states at a glance
                HStack(spacing: 32) {
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.pulseRed.opacity(0.25))
                            .frame(width: 12, height: 12)
                        Text("pulse sent")
                            .font(.system(size: 12, weight: .light, design: .monospaced))
                            .foregroundColor(.white.opacity(0.7))
                    }
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.white.opacity(0.1))
                            .frame(width: 12, height: 12)
                        Text("no pulse")
                            .font(.system(size: 12, weight: .light, design: .monospaced))
                            .foregroundColor(.white.opacity(0.5))
                    }
                }
                .padding(.bottom, 48)
            }
        }
    }

    /// Extracts the day-of-month number from a date as a display string.
    /// - Parameter date: The date to extract from.
    /// - Returns: A string like `"7"` or `"23"`.
    func dayNumber(_ date: Date) -> String {
        let day = Calendar.current.component(.day, from: date)
        return "\(day)"
    }
}
