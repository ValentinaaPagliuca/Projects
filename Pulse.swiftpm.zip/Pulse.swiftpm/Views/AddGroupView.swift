import Foundation
import SwiftUI

/// Screen where the user creates a new Pulse group by giving it a name.
/// On confirmation, the group is added to `appState` and the app navigates to `HomeView`.
struct AddGroupView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    /// The name the user is typing for their new group.
    @State private var groupName: String = ""

    /// Controls the fade-in entrance animation.
    @State private var appeared = false

    /// Triggers the `navigationDestination` to `HomeView` once the group is created.
    @State private var navigateToHome = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {

                // Back button — dismisses this view and returns to the previous screen
                HStack {
                    Button { dismiss() } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 12))
                            Text("back")
                                .font(.system(size: 11, weight: .light, design: .monospaced))
                                .tracking(2)
                        }
                        .foregroundColor(.gray.opacity(0.5))
                    }
                    Spacer()
                }
                .padding(.horizontal, 28)
                .padding(.top, 28)
                .frame(height: 44)

                Spacer()

                VStack(spacing: 40) {

                    // Header
                    VStack(spacing: 12) {
                        Text("name your circle")
                            .font(.custom("Georgia", size: 32))
                            .fontWeight(.light)
                            .foregroundColor(.warmWhite)
                            .tracking(3)
                        Text("this is what your group will be called")
                            .font(.system(size: 10, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.4))
                            .tracking(1)
                    }

                    // Text field with an animated underline that turns red once the user starts typing
                    VStack(spacing: 8) {
                        TextField("", text: $groupName)
                            .placeholder(when: groupName.isEmpty) {
                                Text("circle name...")
                                    .foregroundColor(.gray.opacity(0.3))
                                    .tracking(2)
                            }
                            .font(.system(size: 16, weight: .light, design: .monospaced))
                            .foregroundColor(.warmWhite)
                            .tracking(2)
                            .multilineTextAlignment(.center)
                            .padding(.vertical, 16)

                        Rectangle()
                            .fill(groupName.isEmpty ? Color.surface : Color.pulseRed.opacity(0.5))
                            .frame(height: 1)
                            .animation(.easeInOut, value: groupName.isEmpty)
                    }
                    .padding(.horizontal, 48)

                    // Create button — disabled and visually muted until a name is entered
                    Button {
                        guard !groupName.isEmpty else { return }

                        // Build the new group with a fresh invite code and seed it with the current user
                        let newGroup = PulseGroup(
                            name: groupName,
                            code: PulseGroup.generateCode(),
                            members: [appState.currentUser]
                        )
                        appState.group = newGroup
                        appState.allGroups.append(newGroup)
                        navigateToHome = true
                    } label: {
                        HStack(spacing: 10) {
                            Text("create circle")
                                .font(.system(size: 11, weight: .light, design: .monospaced))
                                .foregroundColor(groupName.isEmpty ? .gray.opacity(0.3) : .warmWhite)
                                .tracking(3)
                            if !groupName.isEmpty {
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 10))
                                    .foregroundColor(.pulseRed)
                            }
                        }
                        .padding(.vertical, 18)
                        .padding(.horizontal, 40)
                        .background(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(groupName.isEmpty ? Color.surface : Color.pulseRed.opacity(0.5), lineWidth: 1)
                        )
                    }
                    .disabled(groupName.isEmpty)
                    .navigationDestination(isPresented: $navigateToHome) {
                        HomeView().environmentObject(appState)
                    }
                }

                Spacer()
                Spacer()
            }
        }
        .navigationBarHidden(true)
        // Fade the whole view in on appear
        .opacity(appeared ? 1 : 0)
        .onAppear {
            withAnimation(.easeIn(duration: 0.4)) { appeared = true }
        }
    }
}
