import Foundation
import SwiftUI

/// Screen where the user enters a 6-character invite code to join an existing group.
/// In the demo build, any valid code spawns a pre-seeded "Besties" group so reviewers
/// can immediately see a populated group without a real backend.
struct JoinGroupView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    /// The code the user is typing.
    @State private var groupCode: String = ""

    /// Validation error shown below the text field, if any.
    @State private var errorMessage: String = ""

    /// Controls the fade-in entrance animation.
    @State private var appeared = false

    /// Triggers the `navigationDestination` to `HomeView` once the group is joined.
    @State private var navigateToHome = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {

                // Back button
                HStack {
                    Button { dismiss() } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 11))
                            Text("back")
                                .font(.system(size: 10, weight: .light, design: .monospaced))
                                .tracking(2)
                        }
                        .foregroundColor(.gray.opacity(0.5))
                    }
                    Spacer()
                }
                .padding(.horizontal, 28)
                .padding(.top, 28)
                .frame(height: 44)

                Spacer()

                VStack(spacing: 40) {

                    // Header
                    VStack(spacing: 12) {
                        Text("enter the code")
                            .font(.custom("Georgia", size: 32))
                            .fontWeight(.light)
                            .foregroundColor(.warmWhite)
                            .tracking(3)
                        Text("ask your circle for their invite code")
                            .font(.system(size: 10, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.4))
                            .tracking(1)
                    }

                    VStack(spacing: 16) {
                        // Large monospaced text field styled to look like a code input
                        TextField("", text: $groupCode)
                            .placeholder(when: groupCode.isEmpty) {
                                Text("XXXXXX")
                                    .foregroundColor(.gray.opacity(0.2))
                                    .tracking(8)
                            }
                            .font(.system(size: 28, weight: .light, design: .monospaced))
                            .foregroundColor(.pulseRed)
                            .tracking(8)
                            .multilineTextAlignment(.center)
                            .textInputAutocapitalization(.characters) // codes are always uppercase
                            .padding(.vertical, 16)

                        // Underline turns red once the user starts typing
                        Rectangle()
                            .fill(groupCode.isEmpty ? Color.surface : Color.pulseRed.opacity(0.5))
                            .frame(height: 1)
                            .animation(.easeInOut, value: groupCode.isEmpty)

                        // Inline validation error — animates in if the code is too short
                        if !errorMessage.isEmpty {
                            Text(errorMessage)
                                .font(.system(size: 9, design: .monospaced))
                                .foregroundColor(.orange)
                                .tracking(1)
                                .transition(.opacity)
                        }
                    }
                    .padding(.horizontal, 48)

                    Button {
                        if groupCode.count >= 4 {
                            // Demo mode: instead of a real network lookup we create a
                            // pre-seeded "Besties" group so the reviewer sees real data
                            let bestiesGroup = PulseGroup(
                                name: "Besties",
                                code: groupCode.uppercased(),
                                members: [
                                    appState.currentUser,
                                    Member(name: "Sara", emoji: "🌙", pulses: [
                                        PulseEntry(date: Date(), type: .temperature, temperature: 0.65),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .draw),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .silence),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .photo),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, type: .temperature, temperature: 0.2),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -5, to: Date())!, type: .silence)
                                    ]),
                                    Member(name: "Marco", emoji: "🔥", pulses: [
                                        PulseEntry(date: Date(), type: .draw),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .temperature, temperature: 0.9),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .photo),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .silence)
                                    ]),
                                    Member(name: "Lila", emoji: "✨", pulses: [
                                        PulseEntry(date: Date(), type: .photo),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .temperature, temperature: 0.45),
                                        PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .draw)
                                    ])
                                ]
                            )
                            appState.group = bestiesGroup
                            // Avoid duplicating the group if the user navigates back and tries again
                            if !appState.allGroups.contains(where: { $0.name == "Besties" }) {
                                appState.allGroups.append(bestiesGroup)
                            }
                            navigateToHome = true
                        } else {
                            withAnimation { errorMessage = "code must be at least 4 characters" }
                        }
                    } label: {
                        HStack(spacing: 10) {
                            Text("find my circle")
                                .font(.system(size: 11, weight: .light, design: .monospaced))
                                .foregroundColor(groupCode.isEmpty ? .gray.opacity(0.3) : .warmWhite)
                                .tracking(3)
                            if !groupCode.isEmpty {
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 10))
                                    .foregroundColor(.pulseRed)
                            }
                        }
                        .padding(.vertical, 18)
                        .padding(.horizontal, 40)
                        .background(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(groupCode.isEmpty ? Color.surface : Color.pulseRed.opacity(0.5), lineWidth: 1)
                        )
                    }
                    .navigationDestination(isPresented: $navigateToHome) {
                        HomeView().environmentObject(appState)
                    }
                }

                Spacer()
                Spacer()
            }
        }
        .navigationBarHidden(true)
        // Fade the whole view in on appear
        .opacity(appeared ? 1 : 0)
        .onAppear {
            withAnimation(.easeIn(duration: 0.4)) { appeared = true }
        }
    }
}
