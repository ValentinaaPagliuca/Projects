import SwiftUI

/// The main screen of the app — shows all members of the active group as pulsing circles
/// and lets the user send their daily gesture or view their history.
struct HomeView: View {
    @EnvironmentObject var appState: AppState

    /// Controls the `SendPulseView` sheet.
    @State private var showSendPulse = false

    /// Controls the `CalendarView` sheet.
    @State private var showCalendar = false

    /// The member whose detail sheet is currently open, if any.
    @State private var selectedMember: Member? = nil

    // Separate opacity values let each section fade in with its own delay
    @State private var headerOpacity: Double = 0
    @State private var circlesOpacity: Double = 0
    @State private var bottomOpacity: Double = 0

    /// Controls the system share sheet for the invite code.
    @State private var shareCode = false

    @Environment(\.dismiss) var dismiss

    /// `true` when the group has no members other than the current user.
    var isEmptyGroup: Bool {
        appState.group.members.filter { $0.id != appState.currentUser.id }.isEmpty
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {

                // HEADER — back navigation + tappable invite code
                HStack {
                    Button {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            dismiss()
                        }
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 11, weight: .light))
                                .foregroundColor(.gray.opacity(0.9))
                            Text("circles")
                                .font(.system(size: 11, weight: .light, design: .monospaced))
                                .foregroundColor(.gray.opacity(0.9))
                                .tracking(2)
                        }
                    }

                    Spacer()

                    // Tapping the code opens the share sheet
                    VStack(alignment: .trailing, spacing: 4) {
                        Text("invite code")
                            .font(.system(size: 11, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.9))
                            .tracking(2)
                        Text(appState.group.code)
                            .font(.system(size: 15, weight: .light, design: .monospaced))
                            .foregroundColor(.pulseRed)
                            .tracking(3)
                            .onTapGesture {
                                shareCode = true
                            }
                    }
                }
                .padding(.horizontal, 28)
                .padding(.top, 56)
                .padding(.bottom, 12)
                .opacity(headerOpacity)

                // Group name and member count
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(appState.group.name)
                            .font(.custom("Georgia", size: 28))
                            .fontWeight(.light)
                            .foregroundColor(.warmWhite)
                            .tracking(2)
                        Text("\(appState.group.members.count) members")
                            .font(.system(size: 15, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.9))
                            .tracking(2)
                    }
                    Spacer()
                }
                .padding(.horizontal, 28)
                .padding(.bottom, 32)
                .opacity(headerOpacity)

                Rectangle()
                    .fill(Color.surface)
                    .frame(height: 1)
                    .padding(.horizontal, 28)

                Spacer()

                // CIRCLES — or empty state if the user is alone in the group
                if isEmptyGroup {
                    emptyGroupView
                        .opacity(circlesOpacity)
                } else {
                    // Members are laid out in two rows of up to 2, with staggered spring entrances
                    VStack(spacing: 52) {
                        HStack(spacing: 44) {
                            ForEach(Array(appState.group.members.prefix(2).enumerated()), id: \.element.id) { index, member in
                                PulseCircle(member: member, size: 90)
                                    .onTapGesture { selectedMember = member }
                                    .opacity(circlesOpacity)
                                    .offset(y: circlesOpacity == 1 ? 0 : 20)
                                    .animation(.spring(response: 0.5).delay(Double(index) * 0.12), value: circlesOpacity)
                            }
                        }

                        HStack(spacing: 44) {
                            ForEach(Array(appState.group.members.dropFirst(2).enumerated()), id: \.element.id) { index, member in
                                PulseCircle(member: member, size: 90)
                                    .onTapGesture { selectedMember = member }
                                    .opacity(circlesOpacity)
                                    .offset(y: circlesOpacity == 1 ? 0 : 20)
                                    .animation(.spring(response: 0.5).delay(Double(index + 2) * 0.12), value: circlesOpacity)
                            }
                        }
                    }
                }

                Spacer()

                // BOTTOM — history shortcut and the main send-pulse CTA
                VStack(spacing: 16) {
                    Button { showCalendar = true } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "circle.grid.3x3")
                                .font(.system(size: 12))
                                .foregroundColor(.gray.opacity(0.9))
                            Text("your history")
                                .font(.system(size: 12, weight: .light, design: .monospaced))
                                .foregroundColor(.gray.opacity(0.9))
                                .tracking(2)
                        }
                    }

                    // Main CTA — disabled and re-labeled once the user has already sent today
                    Button { showSendPulse = true } label: {
                        HStack(spacing: 14) {
                            Circle()
                                .fill(Color.pulseRed)
                                .frame(width: 8, height: 8)
                                .shadow(color: .pulseRed.opacity(0.9), radius: 8)
                            Text(appState.currentUser.sentToday ? "pulse sent today" : "send today's pulse")
                                .font(.system(size: 11, weight: .light, design: .monospaced))
                                .foregroundColor(appState.currentUser.sentToday ? .gray.opacity(0.9) : .warmWhite)
                                .tracking(3)
                        }
                        .padding(.vertical, 20)
                        .padding(.horizontal, 40)
                        .background(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(appState.currentUser.sentToday ? Color.surface : Color.pulseRed.opacity(0.4), lineWidth: 1)
                        )
                    }
                    .disabled(appState.currentUser.sentToday)

                    // Confirmation label — slides up after the pulse is sent
                    if appState.currentUser.sentToday {
                        HStack(spacing: 6) {
                            Circle()
                                .fill(Color.pulseRed)
                                .frame(width: 4, height: 4)
                                .shadow(color: .pulseRed, radius: 4)
                            Text("you're here today")
                                .font(.system(size: 13, weight: .light, design: .monospaced))
                                .foregroundColor(.pulseRed.opacity(0.9))
                                .tracking(2)
                        }
                        .transition(.opacity.combined(with: .move(edge: .bottom)))
                    }
                }
                .opacity(bottomOpacity)
                .padding(.bottom, 48)
            }
        }
        .navigationBarHidden(true)
        .sheet(isPresented: $showSendPulse) {
            SendPulseView().environmentObject(appState)
        }
        .sheet(isPresented: $showCalendar) {
            CalendarView().environmentObject(appState)
        }
        .sheet(item: $selectedMember) { member in
            MemberDetailView(member: member)
        }
        .sheet(isPresented: $shareCode) {
            ShareSheet(items: ["Join my circle on Pulse! Code: \(appState.group.code)"])
        }
        // Three-stage staggered fade: header → circles → bottom bar
        .onAppear {
            withAnimation(.easeOut(duration: 0.7).delay(0.1))  { headerOpacity  = 1 }
            withAnimation(.easeOut(duration: 0.7).delay(0.35)) { circlesOpacity = 1 }
            withAnimation(.easeOut(duration: 0.7).delay(0.6))  { bottomOpacity  = 1 }
        }
    }

    /// Shown when the current user is the only member — prompts them to share the invite code.
    var emptyGroupView: some View {
        VStack(spacing: 28) {
            ZStack {
                Circle()
                    .stroke(Color.surface, lineWidth: 1)
                    .frame(width: 120, height: 120)
                Circle()
                    .stroke(Color.surface.opacity(0.5), lineWidth: 1)
                    .frame(width: 80, height: 80)
                Text(appState.currentUser.emoji)
                    .font(.system(size: 36))
            }

            VStack(spacing: 8) {
                Text("your circle is empty")
                    .font(.custom("Georgia", size: 22))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                    .tracking(2)

                Text("share the code to invite people")
                    .font(.system(size: 13, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(1)
            }

            // Share button — opens the system share sheet with the invite code pre-filled
            Button {
                shareCode = true
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 12))
                        .foregroundColor(.pulseRed)
                    Text("share \(appState.group.code)")
                        .font(.system(size: 11, weight: .light, design: .monospaced))
                        .foregroundColor(.warmWhite)
                        .tracking(3)
                }
                .padding(.vertical, 18)
                .padding(.horizontal, 32)
                .background(
                    RoundedRectangle(cornerRadius: 2)
                        .stroke(Color.pulseRed.opacity(0.5), lineWidth: 1)
                )
            }
        }
    }
}

/// Thin wrapper around `UIActivityViewController` to expose the system share sheet in SwiftUI.
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uvc: UIActivityViewController, context: Context) {}
}
