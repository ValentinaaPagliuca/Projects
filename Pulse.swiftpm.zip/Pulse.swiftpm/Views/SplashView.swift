import SwiftUI
import AVFoundation

/// The first screen the app shows — an animated logo with four pulsing rings
/// and a glowing core. Tapping anywhere navigates to `OnboardingView`.
struct SplashView: View {

    // Each ring gets its own scale state so they can be staggered independently
    @State private var scale1: CGFloat = 1.0
    @State private var scale2: CGFloat = 1.0
    @State private var scale3: CGFloat = 1.0
    @State private var scale4: CGFloat = 1.0

    /// The central dot pulses on a faster cycle than the outer rings.
    @State private var coreScale: CGFloat = 1.0

    /// Opacity values for the text elements — animated in sequence on appear.
    @State private var titleOpacity: Double = 0
    @State private var taglineOpacity: Double = 0
    @State private var tapOpacity: Double = 0

    /// Triggers navigation to `OnboardingView` when the user taps the screen.
    @State private var navigateToOnboarding = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                VStack(spacing: 32) {
                    Spacer()

                    // Animated logo — four rings with increasing opacity toward the center,
                    // each pulsing with a slight delay to create a ripple effect
                    ZStack {
                        Circle()
                            .stroke(Color.pulseRed.opacity(0.10), lineWidth: 1)
                            .frame(width: 220, height: 220)
                            .scaleEffect(scale1)

                        Circle()
                            .stroke(Color.pulseRed.opacity(0.20), lineWidth: 1)
                            .frame(width: 160, height: 160)
                            .scaleEffect(scale2)

                        Circle()
                            .stroke(Color.pulseRed.opacity(0.40), lineWidth: 1)
                            .frame(width: 110, height: 110)
                            .scaleEffect(scale3)

                        Circle()
                            .stroke(Color.pulseRed.opacity(0.70), lineWidth: 1)
                            .frame(width: 68, height: 68)
                            .scaleEffect(scale4)

                        // Glowing core dot
                        Circle()
                            .fill(Color.pulseRed)
                            .frame(width: 18, height: 18)
                            .scaleEffect(coreScale)
                            .shadow(color: Color.pulseRed.opacity(0.8), radius: 12)
                            .shadow(color: Color.pulseRed.opacity(0.3), radius: 30)
                    }

                    Text("PULSE")
                        .font(.custom("Georgia", size: 58))
                        .fontWeight(.light)
                        .foregroundColor(.warmWhite)
                        .tracking(12)
                        .opacity(titleOpacity)

                    Text("tap anywhere to begin")
                        .font(.system(size: 15, weight: .light, design: .monospaced))
                        .foregroundColor(.gray.opacity(0.9))
                        .tracking(2)
                        .opacity(tapOpacity)
                        .padding(.bottom, 48)

                    Spacer()
                }
            }
            .onTapGesture {
                navigateToOnboarding = true
            }
            .navigationDestination(isPresented: $navigateToOnboarding) {
                OnboardingView()
            }
            .onAppear {
                startAnimations()
            }
        }
        .preferredColorScheme(.dark)
    }

    /// Kicks off all the splash animations in sequence.
    /// Each outer ring is delayed by 0.3s to produce a ripple, and the core pulses independently.
    private func startAnimations() {
        let timings: [(Double, Binding<CGFloat>)] = [
            (0.0, $scale1),
            (0.3, $scale2),
            (0.6, $scale3),
            (0.9, $scale4)
        ]

        // Stagger each ring's breathing animation by its delay
        for (delay, binding) in timings {
            withAnimation(
                .easeInOut(duration: 2.8)
                .repeatForever(autoreverses: true)
                .delay(delay)
            ) {
                binding.wrappedValue = 1.06
            }
        }

        // Core dot pulses faster than the rings
        withAnimation(.easeInOut(duration: 1.4).repeatForever(autoreverses: true)) {
            coreScale = 1.2
        }

        // Text elements fade in one after another
        withAnimation(.easeIn(duration: 1.2).delay(0.4)) { titleOpacity   = 1 }
        withAnimation(.easeIn(duration: 1.2).delay(0.9)) { taglineOpacity = 1 }
        withAnimation(.easeIn(duration: 1.0).delay(1.8)) { tapOpacity     = 1 }
    }
}
