import SwiftUI

/// The first screen new users see — walks them through three steps:
/// choice (create or join) → group setup → profile setup.
struct OnboardingView: View {
    @EnvironmentObject var appState: AppState

    /// Tracks which onboarding step is currently visible.
    @State private var step: OnboardingStep = .choice

    /// The user's chosen display name.
    @State private var name: String = ""

    /// The user's chosen emoji avatar.
    @State private var selectedEmoji: String = "💫"

    /// The invite code entered when joining an existing group.
    @State private var groupCode: String = ""

    /// Triggers navigation to `GroupsView` once onboarding is complete.
    @State private var showHome = false

    /// Cross-fade opacity used for step transitions.
    @State private var contentOpacity: Double = 0

    /// Inline validation error shown on the join step.
    @State private var errorMessage: String = ""

    /// The group name entered on the create step.
    @State private var groupName: String = ""

    /// Emoji palette offered to the user during profile setup.
    let emojis = ["💫", "🌙", "🔥", "✨", "🌊", "🌿", "⚡", "🎯", "🖤", "🌸"]

    /// The four discrete states of the onboarding flow.
    enum OnboardingStep {
        case choice, create, join, profile
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                VStack(spacing: 0) {

                    // BACK BUTTON — hidden on the first step, context-aware on later steps
                    HStack {
                        if step != .choice {
                            Button {
                                // Fade out, switch step, fade back in
                                withAnimation(.easeInOut(duration: 0.25)) { contentOpacity = 0 }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                                    step = step == .profile ? (groupCode.isEmpty ? .create : .join) : .choice
                                    withAnimation(.easeIn(duration: 0.35)) { contentOpacity = 1 }
                                }
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "arrow.left")
                                        .font(.system(size: 11))
                                    Text("back")
                                        .font(.system(size: 13, weight: .light, design: .monospaced))
                                        .tracking(2)
                                }
                                .foregroundColor(.gray.opacity(0.9))
                            }
                            .transition(.opacity)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 28)
                    .padding(.top, 28)
                    .frame(height: 44)

                    Spacer()

                    // Active step content — swapped with a cross-fade on each transition
                    Group {
                        switch step {
                        case .choice:  choiceView
                        case .create:  createView
                        case .join:    joinView
                        case .profile: profileView
                        }
                    }
                    .opacity(contentOpacity)

                    Spacer()
                    Spacer()
                }
            }
            .navigationBarHidden(true)
            .navigationDestination(isPresented: $showHome) {
                GroupsView()
            }
            .onAppear {
                withAnimation(.easeIn(duration: 0.8).delay(0.2)) {
                    contentOpacity = 1
                }
            }
        }
    }

    // MARK: - Step 1: Choice

    /// Landing screen — the user picks whether to create a new group or join an existing one.
    var choiceView: some View {
        VStack(spacing: 52) {

            // App logo — three concentric rings with a glowing red dot
            VStack(spacing: 16) {
                ZStack {
                    Circle()
                        .stroke(Color.pulseRed.opacity(0.12), lineWidth: 1)
                        .frame(width: 80, height: 80)
                    Circle()
                        .stroke(Color.pulseRed.opacity(0.25), lineWidth: 1)
                        .frame(width: 56, height: 56)
                    Circle()
                        .fill(Color.pulseRed)
                        .frame(width: 10, height: 10)
                        .shadow(color: .pulseRed.opacity(0.8), radius: 8)
                }

                Text("PULSE")
                    .font(.custom("Georgia", size: 42))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                    .tracking(8)

                Text("one gesture. every day. that's enough.")
                    .font(.system(size: 17, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(1)
                    .multilineTextAlignment(.center)
            }

            // CTA buttons
            VStack(spacing: 14) {
                Button { transition(to: .create) } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "plus.circle")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(.pulseRed)
                        Text("create a new circle")
                            .font(.system(size: 14, weight: .light, design: .monospaced))
                            .foregroundColor(.warmWhite)
                            .tracking(3)
                        Spacer()
                        Image(systemName: "arrow.right")
                            .font(.system(size: 10))
                            .foregroundColor(.pulseRed.opacity(0.8))
                    }
                    .padding(.vertical, 20)
                    .padding(.horizontal, 24)
                    .background(
                        RoundedRectangle(cornerRadius: 2)
                            .stroke(Color.pulseRed.opacity(0.5), lineWidth: 1)
                    )
                }

                Button { transition(to: .join) } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "person.2")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(.pulseRed)
                        Text("join an existing circle")
                            .font(.system(size: 14, weight: .light, design: .monospaced))
                            .foregroundColor(.warmWhite)
                            .tracking(3)
                        Spacer()
                        Image(systemName: "arrow.right")
                            .font(.system(size: 10))
                            .foregroundColor(.gray.opacity(0.8))
                    }
                    .padding(.vertical, 20)
                    .padding(.horizontal, 24)
                    .background(
                        RoundedRectangle(cornerRadius: 2)
                            .stroke(Color.pulseRed.opacity(0.5), lineWidth: 1)
                    )
                }
            }
            .padding(.horizontal, 28)
        }
    }

    // MARK: - Step 2A: Create

    /// The user names their new group before moving on to set up their profile.
    var createView: some View {
        VStack(spacing: 40) {

            VStack(spacing: 12) {
                Text("Name your circle")
                    .font(.custom("Georgia", size: 32))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                    .tracking(3)
                Text("this is what your group will be called")
                    .font(.system(size: 13, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(1)
            }

            // Text field with a border that turns red once the user starts typing
            VStack(spacing: 0) {
                TextField("", text: $groupName)
                    .placeholder(when: groupName.isEmpty) {
                        Text("circle name...")
                            .foregroundColor(.gray.opacity(0.5))
                            .tracking(2)
                            .font(.system(size: 16, weight: .light, design: .monospaced))
                    }
                    .font(.system(size: 16, weight: .light, design: .monospaced))
                    .foregroundColor(.warmWhite)
                    .tracking(2)
                    .multilineTextAlignment(.center)
                    .padding(.vertical, 18)
                    .padding(.horizontal, 16)
            }
            .background(
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.surface.opacity(0.4))
                    .overlay(
                        RoundedRectangle(cornerRadius: 2)
                            .stroke(
                                groupName.isEmpty ? Color.gray.opacity(0.3) : Color.pulseRed.opacity(0.6),
                                lineWidth: 1
                            )
                            .animation(.easeInOut, value: groupName.isEmpty)
                    )
            )
            .padding(.horizontal, 32)

            Button {
                guard !groupName.isEmpty else { return }
                // Create the group now; the current user will be added properly in the profile step
                appState.group = PulseGroup(
                    name: groupName,
                    code: PulseGroup.generateCode(),
                    members: [appState.currentUser]
                )
                transition(to: .profile)
            } label: {
                HStack(spacing: 10) {
                    Text("continue")
                        .font(.system(size: 14, weight: .medium, design: .monospaced))
                        .foregroundColor(groupName.isEmpty ? .gray.opacity(0.4) : .warmWhite)
                        .tracking(3)
                    if !groupName.isEmpty {
                        Image(systemName: "arrow.right")
                            .font(.system(size: 12))
                            .foregroundColor(.warmWhite)
                    }
                }
                .padding(.vertical, 20)
                .padding(.horizontal, 48)
                .background(
                    RoundedRectangle(cornerRadius: 2)
                        .fill(groupName.isEmpty ? Color.clear : Color.pulseRed)
                        .overlay(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(
                                    groupName.isEmpty ? Color.surface : Color.clear,
                                    lineWidth: 1
                                )
                        )
                )
                .animation(.easeInOut(duration: 0.2), value: groupName.isEmpty)
            }
            .disabled(groupName.isEmpty)
        }
    }

    // MARK: - Step 2B: Join

    /// The user enters an invite code to join a friend's group.
    /// In the demo build any valid code spawns a pre-seeded "Besties" group.
    var joinView: some View {
        VStack(spacing: 40) {

            VStack(spacing: 12) {
                Text("Enter the code")
                    .font(.custom("Georgia", size: 32))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                    .tracking(3)
                Text("ask your circle for their invite code")
                    .font(.system(size: 13, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(1)
            }

            VStack(spacing: 16) {
                // Large, tracked code input — auto-capitalizes for UX convenience
                TextField("", text: $groupCode)
                    .placeholder(when: groupCode.isEmpty) {
                        Text("XXXXXX")
                            .foregroundColor(.gray.opacity(0.4))
                            .tracking(8)
                    }
                    .font(.system(size: 28, weight: .light, design: .monospaced))
                    .foregroundColor(.pulseRed)
                    .tracking(8)
                    .multilineTextAlignment(.center)
                    .textInputAutocapitalization(.characters)
                    .padding(.vertical, 16)

                Rectangle()
                    .fill(groupCode.isEmpty ? Color.surface : Color.pulseRed.opacity(0.5))
                    .frame(height: 1)
                    .animation(.easeInOut, value: groupCode.isEmpty)

                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(.orange)
                        .tracking(1)
                        .transition(.opacity)
                }
            }
            .padding(.horizontal, 48)

            actionButton(title: "find my circle") {
                if groupCode.count >= 4 {
                    // Demo: seed a Besties group so the reviewer sees a realistic populated group
                    appState.group = PulseGroup(
                        name: "Besties",
                        code: groupCode.uppercased(),
                        members: [
                            Member(name: "You", emoji: "💫", pulses: []),
                            Member(name: "Sara", emoji: "🌙", pulses: [
                                PulseEntry(date: Date(), type: .temperature, temperature: 0.65),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .draw),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .silence),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .photo),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, type: .temperature, temperature: 0.2),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -5, to: Date())!, type: .silence),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -6, to: Date())!, type: .draw)
                            ]),
                            Member(name: "Marco", emoji: "🔥", pulses: [
                                PulseEntry(date: Date(), type: .draw),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .temperature, temperature: 0.9),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .photo),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .silence),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, type: .temperature, temperature: 0.4)
                            ]),
                            Member(name: "Lila", emoji: "✨", pulses: [
                                PulseEntry(date: Date(), type: .photo),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .temperature, temperature: 0.45),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .draw),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, type: .silence),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, type: .photo),
                                PulseEntry(date: Calendar.current.date(byAdding: .day, value: -5, to: Date())!, type: .temperature, temperature: 0.75)
                            ])
                        ]
                    )
                    transition(to: .profile)
                } else {
                    withAnimation { errorMessage = "code must be at least 4 characters" }
                }
            }
        }
    }

    // MARK: - Step 3: Profile

    /// The user picks a name and emoji avatar before entering the app.
    var profileView: some View {
        VStack(spacing: 36) {

            VStack(spacing: 12) {
                Text("Who are you?")
                    .font(.custom("Georgia", size: 32))
                    .fontWeight(.light)
                    .foregroundColor(.warmWhite)
                    .tracking(3)
                Text("your circle will recognize you by this")
                    .font(.system(size: 13, weight: .light, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.9))
                    .tracking(1)
            }

            VStack(spacing: 20) {
                // Live emoji preview inside the signature concentric rings
                ZStack {
                    Circle()
                        .stroke(Color.pulseRed.opacity(0.2), lineWidth: 1)
                        .frame(width: 96, height: 96)
                    Circle()
                        .stroke(Color.pulseRed.opacity(0.5), lineWidth: 1)
                        .frame(width: 70, height: 70)
                    Text(selectedEmoji)
                        .font(.system(size: 36))
                        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: selectedEmoji)
                }

                // Horizontal emoji picker — selected emoji gets a red ring and scales up
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 17) {
                        ForEach(emojis, id: \.self) { emoji in
                            Text(emoji)
                                .font(.system(size: 26))
                                .padding(10)
                                .background(
                                    Circle()
                                        .stroke(
                                            selectedEmoji == emoji ? Color.pulseRed : Color.surface,
                                            lineWidth: 1
                                        )
                                )
                                .scaleEffect(selectedEmoji == emoji ? 1.15 : 1.0)
                                .animation(.spring(response: 0.3, dampingFraction: 0.6), value: selectedEmoji)
                                .onTapGesture { selectedEmoji = emoji }
                                .padding(.vertical, 6)
                        }
                    }
                    .padding(.horizontal, 28)
                }
                .clipped(antialiased: false)
            }

            // Name field with a red underline that appears once the user starts typing
            VStack(spacing: 8) {
                TextField("", text: $name)
                    .placeholder(when: name.isEmpty) {
                        Text("your name...")
                            .foregroundColor(.gray.opacity(0.5))
                            .tracking(2)
                    }
                    .font(.system(size: 16, weight: .light, design: .monospaced))
                    .foregroundColor(.warmWhite)
                    .tracking(2)
                    .multilineTextAlignment(.center)
                    .padding(.vertical, 16)

                Rectangle()
                    .fill(name.isEmpty ? Color.surface : Color.pulseRed.opacity(0.8))
                    .frame(height: 2)
                    .animation(.easeInOut, value: name.isEmpty)
            }
            .padding(.horizontal, 48)

            actionButton(title: "enter the circle", disabled: name.isEmpty) {
                // Apply the chosen name and emoji to both currentUser and their slot in the group
                appState.currentUser.name = name
                appState.currentUser.emoji = selectedEmoji

                if let idx = appState.group.members.firstIndex(where: { $0.name == "You" || $0.id == appState.currentUser.id }) {
                    appState.group.members[idx].name = name
                    appState.group.members[idx].emoji = selectedEmoji
                    appState.group.members[idx].id = appState.currentUser.id
                }

                // Add the group to allGroups, or update it if it already exists
                if !appState.allGroups.contains(where: { $0.id == appState.group.id }) {
                    appState.allGroups.append(appState.group)
                } else {
                    if let idx = appState.allGroups.firstIndex(where: { $0.id == appState.group.id }) {
                        appState.allGroups[idx] = appState.group
                    }
                }

                showHome = true
            }
        }
    }

    // MARK: - Helpers

    /// Animates between onboarding steps with a quick cross-fade.
    func transition(to newStep: OnboardingStep) {
        withAnimation(.easeInOut(duration: 0.25)) { contentOpacity = 0 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            step = newStep
            withAnimation(.easeIn(duration: 0.35)) { contentOpacity = 1 }
        }
    }

    /// Reusable CTA button used across multiple onboarding steps.
    /// Renders in a muted style when disabled, and shows an arrow when active.
    /// - Parameters:
    ///   - title: The button label.
    ///   - disabled: Whether the button should be grayed out and non-interactive.
    ///   - action: The closure to run on tap.
    @ViewBuilder
    func actionButton(title: String, disabled: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Text(title)
                    .font(.system(size: 14, weight: .light, design: .monospaced))
                    .foregroundColor(disabled ? .gray.opacity(0.9) : .warmWhite)
                    .tracking(3)
                if !disabled {
                    Image(systemName: "arrow.right")
                        .font(.system(size: 10))
                        .foregroundColor(.pulseRed)
                }
            }
            .padding(.vertical, 18)
            .padding(.horizontal, 40)
            .background(
                RoundedRectangle(cornerRadius: 2)
                    .stroke(disabled ? Color.surface : Color.pulseRed.opacity(0.5), lineWidth: 1)
            )
        }
        .disabled(disabled)
    }
}

/// A View modifier that overlays a placeholder on any text field when it's empty.
/// Used throughout the app to show custom-styled placeholder text.
extension View {
    func placeholder<Content: View>(when shouldShow: Bool, @ViewBuilder placeholder: () -> Content) -> some View {
        ZStack(alignment: .center) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}
