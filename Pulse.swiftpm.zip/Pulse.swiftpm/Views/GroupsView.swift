import SwiftUI

/// The main hub where the user sees all their groups and can create or join new ones.
struct GroupsView: View {
    @EnvironmentObject var appState: AppState

    /// Controls the staggered entrance animation for the whole view.
    @State private var appeared = false

    /// Toggles the "create / join" options panel below the add button.
    @State private var showAddOptions = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                VStack(spacing: 0) {

                    // HEADER — personalized greeting with the user's name and emoji
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("welcome back")
                                .font(.system(size: 14, weight: .light, design: .monospaced))
                                .foregroundColor(.gray.opacity(0.9))
                                .tracking(3)
                            Text(appState.currentUser.name)
                                .font(.custom("Georgia", size: 28))
                                .fontWeight(.light)
                                .foregroundColor(.warmWhite)
                                .tracking(2)
                        }
                        Spacer()
                        Text(appState.currentUser.emoji)
                            .font(.system(size: 36))
                    }
                    .padding(.horizontal, 28)
                    .padding(.top, 60)
                    .padding(.bottom, 40)
                    .opacity(appeared ? 1 : 0)
                    .offset(y: appeared ? 0 : -20)
                    .animation(.easeOut(duration: 0.6).delay(0.1), value: appeared)

                    Rectangle()
                        .fill(Color.surface)
                        .frame(height: 1)
                        .padding(.horizontal, 28)

                    ScrollView {
                        VStack(spacing: 16) {

                            // Section title + circle count
                            HStack {
                                Text("your circles")
                                    .font(.system(size: 14, weight: .light, design: .monospaced))
                                    .foregroundColor(.gray.opacity(0.9))
                                    .tracking(3)
                                Spacer()
                                Text("\(appState.allGroups.count) circles")
                                    .font(.system(size: 14, weight: .light, design: .monospaced))
                                    .foregroundColor(.gray.opacity(0.9))
                                    .tracking(2)
                            }
                            .padding(.horizontal, 28)
                            .padding(.top, 32)

                            // Each group gets a card with a staggered spring entrance
                            ForEach(Array(appState.allGroups.enumerated()), id: \.element.id) { index, group in
                                GroupCard(group: group, isOwner: group.members.first?.id == appState.currentUser.id)
                                    .opacity(appeared ? 1 : 0)
                                    .offset(y: appeared ? 0 : 30)
                                    .animation(
                                        .spring(response: 0.5, dampingFraction: 0.8)
                                            .delay(Double(index) * 0.15 + 0.3),
                                        value: appeared
                                    )
                            }

                            // ADD BUTTON — rotates to an X when the options panel is open
                            Button {
                                withAnimation(.spring(response: 0.4)) {
                                    showAddOptions.toggle()
                                }
                            } label: {
                                HStack(spacing: 12) {
                                    ZStack {
                                        Circle()
                                            .stroke(Color.surface, lineWidth: 1)
                                            .frame(width: 32, height: 32)
                                        Image(systemName: "plus")
                                            .font(.system(size: 14, weight: .light))
                                            .foregroundColor(.gray.opacity(0.9))
                                            .rotationEffect(.degrees(showAddOptions ? 45 : 0))
                                            .animation(.spring(response: 0.3), value: showAddOptions)
                                    }
                                    Text(showAddOptions ? "cancel" : "add a circle")
                                        .font(.system(size: 13, weight: .light, design: .monospaced))
                                        .foregroundColor(.gray.opacity(0.9))
                                        .tracking(2)
                                    Spacer()
                                }
                                .padding(.horizontal, 28)
                                .padding(.vertical, 8)
                            }
                            .opacity(appeared ? 1 : 0)
                            .animation(.easeIn(duration: 0.4).delay(0.5), value: appeared)

                            // Expandable options — slide in from the top when showAddOptions is true
                            if showAddOptions {
                                VStack(spacing: 12) {
                                    NavigationLink(destination: AddGroupView().environmentObject(appState)) {
                                        HStack(spacing: 14) {
                                            Image(systemName: "plus.circle")
                                                .font(.system(size: 14, weight: .light))
                                                .foregroundColor(.pulseRed)
                                            Text("create a new circle")
                                                .font(.system(size: 11, weight: .light, design: .monospaced))
                                                .foregroundColor(.warmWhite)
                                                .tracking(3)
                                            Spacer()
                                            Image(systemName: "arrow.right")
                                                .font(.system(size: 10))
                                                .foregroundColor(.pulseRed.opacity(0.6))
                                        }
                                        .padding(.vertical, 18)
                                        .padding(.horizontal, 24)
                                        .background(RoundedRectangle(cornerRadius: 2).stroke(Color.pulseRed.opacity(0.4), lineWidth: 1))
                                    }

                                    NavigationLink(destination: JoinGroupView().environmentObject(appState)) {
                                        HStack(spacing: 14) {
                                            Image(systemName: "person.2")
                                                .font(.system(size: 14, weight: .light))
                                                .foregroundColor(.pulseRed)
                                            Text("join an existing circle")
                                                .font(.system(size: 11, weight: .light, design: .monospaced))
                                                .foregroundColor(.warmWhite)
                                                .tracking(3)
                                            Spacer()
                                            Image(systemName: "arrow.right")
                                                .font(.system(size: 10))
                                                .foregroundColor(.pulseRed.opacity(0.6))
                                        }
                                        .padding(.vertical, 18)
                                        .padding(.horizontal, 24)
                                        .background(RoundedRectangle(cornerRadius: 2).stroke(Color.pulseRed.opacity(0.4), lineWidth: 1))
                                    }
                                }
                                .padding(.horizontal, 28)
                                .transition(.opacity.combined(with: .move(edge: .top)))
                            }

                            Spacer().frame(height: 40)
                        }
                    }
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                withAnimation { appeared = true }
            }
        }
    }
}

/// A tappable card representing a single group, showing its name, member previews, and activity.
struct GroupCard: View {
    let group: PulseGroup

    /// `true` if the current user is the first member (i.e. they created the group).
    let isOwner: Bool

    @EnvironmentObject var appState: AppState

    /// Number of members who have already sent a pulse today.
    var activeToday: Int {
        group.members.filter { $0.sentToday }.count
    }

    var body: some View {
        // Tapping navigates to HomeView and switches the active group
        NavigationLink {
            HomeView()
                .environmentObject(appState)
                .onAppear {
                    appState.switchToGroup(group)
                }
        } label: {
            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack(spacing: 8) {
                            Text(group.name)
                                .font(.custom("Georgia", size: 22))
                                .fontWeight(.light)
                                .foregroundColor(.warmWhite)
                                .tracking(2)

                            // "owner" badge — only shown if this user created the group
                            if isOwner {
                                Text("owner")
                                    .font(.system(size: 12, weight: .light, design: .monospaced))
                                    .foregroundColor(.pulseRed)
                                    .tracking(2)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 3)
                                    .background(RoundedRectangle(cornerRadius: 2).stroke(Color.pulseRed.opacity(0.9), lineWidth: 1))
                            }
                        }
                        Text("\(group.members.count) members · \(activeToday) here today")
                            .font(.system(size: 12, weight: .light, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.9))
                            .tracking(1)
                    }
                    Spacer()
                    Image(systemName: "arrow.right")
                        .font(.system(size: 11))
                        .foregroundColor(.pulseRed.opacity(0.6))
                }

                HStack(spacing: 12) {
                    // Show up to 4 member emoji previews; red ring = sent today, faded = long silent
                    ForEach(group.members.prefix(4)) { member in
                        ZStack {
                            Circle()
                                .stroke(member.sentToday ? Color.pulseRed.opacity(0.9) : Color.surface, lineWidth: 1)
                                .frame(width: 32, height: 32)
                            Text(member.emoji)
                                .font(.system(size: 14))
                                .opacity(member.daysMissing >= 2 ? 0.3 : 1.0)
                        }
                    }
                    // Overflow indicator for groups with more than 4 members
                    if group.members.count > 4 {
                        Text("+\(group.members.count - 4)")
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundColor(.gray.opacity(0.4))
                    }
                    Spacer()
                    // Invite code displayed subtly for easy sharing
                    Text(group.code)
                        .font(.system(size: 10, weight: .light, design: .monospaced))
                        .foregroundColor(.gray.opacity(0.9))
                        .tracking(2)
                }
            }
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.surface.opacity(0.3))
                    .overlay(RoundedRectangle(cornerRadius: 2).stroke(Color.surface, lineWidth: 1))
            )
        }
        .padding(.horizontal, 28)
    }
}
