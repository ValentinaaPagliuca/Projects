#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_LENGTH 256

typedef struct {
  char * nome; //  Stringa che contiene la domanda dell'utente
  int monte_premi;  // Variabile intera che contiene il montepremi del giocatore, che è equiparabile al suo punteggio
} giocatore; // Questa struttura viene utilizzata durante il gioco per memorizzare il nome dell'utente e il suo punteggio


typedef struct {
  char *domanda;  // Stringa che contiene la domanda da porre all'utente
  char **opzioni; // Array dinamico di stringhe che contiene le due opzioni
                  // possibili
  char *risposta; // Stringa che contiene la risposta corretta
} domanda; // Questa struttura viene utilizzata durante il gioco dalla tripletta e della sfida finale

// Dichiarazione funzioni globali
int contaRigheFile(char *);
int num_casuale(int, int);
void trasforma(char *);


int main(int argc, const char *argv[]) {
  // Dichiarazione delle funzioni
  int tripletta(void);
  int pesca_a_sorpresa(void);
  int gioco_finale(int);
  void regole(void);
  char *leggiRiga(char *, int);
  void salvo(char *, int);
  void riordina(char *, int);

  // Dichiarazioni variabili
  int monte_premi = 0;   // Monte premi iniziale
  char risposta[BUFSIZ]; // Per sapere se l'utente sa giocare
  char nome[BUFSIZ]; // Nickname del giocatore
  int controllo = 1; // Variabile d'appoggio per gestire i cicli

  // INIZIO DEL GIOCO
  printf(
      "Benvenuto nel gioco di AVANTI UN ALTRO.\nInserisci il tuo nickname: ");
  scanf("%s", nome);
  trasforma(nome);

  do {
    printf("Ciao %s sai come si gioca?\n1) Si\n2) No\nDigita la tua risposta: ", nome);
    scanf("%s", risposta);
    getchar();
    trasforma(risposta);

    if (strcmp(risposta, "no") == 0) {
      regole();
      printf("Perfetto! Ora sei pronto per giocare, iniziamo subito!\n");

      controllo = 0;
    } else if (strcmp(risposta, "si") == 0) {
      printf("Perfetto! Dato che sai già le regole, iniziamo subito!\n");
      printf("Il tuo monte premi iniziale ammonta a %d €.\n", monte_premi);

      controllo = 0;
    } else {
      printf("Per favore digita correttamente o Si o No");
    }
  } while (controllo == 1);

  // GIOCO 
   if(tripletta() == 0){
     printf("Hai passato la prima prova!\n\n");
     monte_premi = pesca_a_sorpresa();
    
     if (monte_premi > 0) {
      printf("Complimenti, adesso passeremo al gioco finale:\n ");
      monte_premi = gioco_finale(monte_premi);
      if (monte_premi > 0) {
        salvo(nome, monte_premi);
        riordina(nome, monte_premi);
      } else {
        printf("Hai perso! Non verrai inserito all'interno della classifica. AVANTI UN ALTRO");
      }
     } else {
         printf("Eliminato dalla pesca a sorpresa! AVANTI UN ALTRO\n");
     }
   } else {
     printf("Hai sbagliato la tripletta! AVANTI UN ALTRO\n");
    } 
  return 0; 
}

void regole(void) {
  char risposta[BUFSIZ];

  printf("+----------------------------------------------------------------------------------------+\n");
  printf("|                                        REGOLE                                          |\n");
  printf("|                                                                                        |\n");
  printf("|Eccoti una spiegazione delle regole per iniziare a giocare. Il gioco si sviluppa in due |\n");
  printf("|fasi, una iniziale e una finale. Nella prima fase i concorrenti partecipano alla        |\n");
  printf("|Tripletta, dove devono rispondere correttamente ad almeno tre domande su quattro per non|\n");
  printf("|essere eliminati.                                                                       |\n");
  printf("|                                                                                        |\n");
  printf("|Successivamente i concorrenti sono chiamati a pescare un rotolo chiamato pidigozzo, che |\n");
  printf("|contiene una cifra del montepremi. Si può così decidere se fermarsi e diventare campione|\n");
  printf("|o proseguire nel gioco per cercare di aumentare il montepremi, pescando un ulteriore    |\n");
  printf("|pidigozzo che andrà a variare la cifra con giochi vari.                                 |\n");
  printf("|Si può pescare Lo iettatore, La Bona Sorte e Avanti un altro!, con cui il concorrente   |\n");
  printf("|viene automaticamente eliminato.                                                        |\n");
  printf("|                                                                                        |\n");
  printf("|Nella parte finale del gioco vengono aggiunti 100.000 euro al montepremi accumulato     |\n");
  printf("|durante il corso delle varie domande. Il gioco finale consiste nel dare la risposta     |\n");
  printf("|sbagliata a 21 domande di cultura generale con doppia opzione.                          |\n");
  printf("|                                                                                        |\n");
  printf("|Ogni volta che il giocatore sbaglia, deve ricominciare da capo. Per ogni risposta       |\n");
  printf("|sbagliata ne perde 500 €. Se il concorrente non dovesse riuscire a completare non     |\n");
  printf("|vincerà il premio per il quale stava giocando.                                          |\n");
  printf("+----------------------------------------------------------------------------------------+\n");

  printf("Ti senti pronto? Rispondi con \"si\" o \"no\": ");
  scanf("%s", risposta);
  getchar();

  trasforma(risposta);

  if (strcmp(risposta, "no") == 2) {
    printf("Ma come no?\n Prova a giocare che capisci tutto!\n\n");
  }
}

char *leggiRiga(char *nomeFile, int numRiga) {
  FILE *fpRead = fopen(nomeFile, "r");

  if (fpRead == NULL) {
    printf("Errore nell'apertura del file :(");
    return NULL;
  }
  char *line = (char *)malloc(MAX_LENGTH * sizeof(char));
  int currentLine = 1;

  while (fgets(line, MAX_LENGTH, fpRead) != NULL) {
    if (currentLine == numRiga) {
      fclose(fpRead);
      return line; // Restituisco la riga letta
    }
    currentLine++;
  }

  fclose(fpRead);
  free(line);
  return NULL;
}

int tripletta() {
  // Dichiarazione delle variabili
  int numRighe = 0;
  int n = 0;   // Variabile d'appoggio per usare domande random
  int err = 0; // Variabile contatore che memorizza la quantità di errori
               // commessi dal giocatore
  int rispCorrette = 1; // Variabile contatore che indica le domande fatte
  int round = 1;
  char * riga; // Riga che conterrà le sottostringhe divise dal simbolo "-"
  char * str;  // Questa è una stringa di appoggio che conterrà la sottostringa
              // estrapolata dall stringa principale riga
  char s[BUFSIZ]; //Stringa ausiliare

  char fileDomande[] = "domande_tripletta.txt";
  char fileRisposte[] = "risposte_tripletta.txt";

  FILE *file_domande;
  FILE *file_risposte;

  domanda *domande; // L'array domande è un array dinamico di strutture Domanda

  numRighe = contaRigheFile(
      fileDomande); // Attraverso la chiamata della funzione contaRigheFile sono
                    // in grado di scoprire quante domande sono presenti nel
                    // file. Il valore ottenuto lo inserisco nella variabile
                    // numRighe

  domande = (domanda *)malloc(
      numRighe * sizeof(domanda)); // Alloco la quantità corretta di memoria
                                   // necessaria a contenere tutte le domande e
                                   // le risposte presenti nei file

  // INSERIAMO TUTTE LE DOMANDE ALL'INTERNO DELL'ARRAY DINAMICO DI DOMANDE
  for (int i = 1; i <= numRighe; i++) {
    riga = leggiRiga(fileDomande,
                     i); // Inserisco nella variabile riga la riga appena letta
                         // dal file contenente le domande
    riga[strlen(riga) - 1] = '\0'; // Elimino l'invio dalla riga e lo sostiuisco
                                   // con il terminatore di stringa
    domande[i - 1].domanda = malloc(
        strlen(riga) * sizeof(char)); // Vado ad allocare lo spazio necessario
                                      // per poter contenere la domanda
    strcpy(domande[i - 1].domanda,
           riga); // Copio la riga (contenente la domanda) nell'array dinamico
                  // che contiene tutte le domande
    // IMPORTANTE: Decremento di 1 ogni volta perché l'indice del nostro ciclo
    // per poter leggere le righe è stato impostato ad 1
  }

  // INSERIAMO TUTTE LE OPZIONI E RISPOSTE ALL'INTERNO DELL'ARRAY DINAMICO DI
  // DOMANDE
  for (int i = 1; i <= numRighe; i++) {
    domande[i - 1].opzioni =
        malloc(2 * sizeof(char *)); // Sto allocando lo spazio nella memoria
                                    // dinamica per poter contenere due stringhe
                                    // (ancora non conosco la loro lunghezza)
    
    riga = leggiRiga(fileRisposte, i); // Leggo la riga dal file composta dalle opzioni e
                                       // dalla risposta corretta separate da un trattino (-)
    str = strtok(riga, "-"); // Inizio la suddivisione della stringa utilizzando il trattino
                             // ("-") come delimitatore. La funzione strtok restituisce il
                             // primo token (o sottostringa) trovato prima del delimitatore.
    
    domande[i - 1].opzioni[0] = malloc(strlen(str) * sizeof(char)); // Vado ad allocare lo spazio necessario per poter
                                                                    // memorizzare la sottostringa precedentemente estratta
    strcpy(domande[i - 1].opzioni[0], str); // Copio la sottostringa nella prima
                                            // opzione della struttura domanda

    str = strtok(NULL, "-"); // Continua la suddivisione utilizzando il trattino come
                             // delimitatore. NULL come primo argomento indica a strtok
                             // di continuare dalla posizione corrente nella stringa.
    domande[i - 1].opzioni[1] = malloc(strlen(str) * sizeof(char));
    strcpy(domande[i - 1].opzioni[1], str);

    str = strtok(NULL, "-");
    domande[i - 1].risposta = malloc(strlen(str) * sizeof(char));

    if (i != numRighe) {
      str[strlen(str) - 1] = '\0';
    }

    strcpy(domande[i - 1].risposta, str);
  }

  printf("\nBenvenuto nella parte iniziale del gioco: Tripletta!\nRispondi a "
         "tre domande su 4 e puoi passare al prossimo turno!\n");

  do {
    n = num_casuale(
        0, (numRighe - 1)); // Generazione del numero casuale che permetterà di
                            // proporre la domanda al concorrente
    printf("\n\t\t\t\t\t\tDOMANDA %d\n", round);
    printf("%s\n", domande[n].domanda);
    printf("Le opzioni sono:\t\t%s\t\t%s\n", domande[n].opzioni[0],
           domande[n].opzioni[1]);
    printf("Scrivi qui la tua risposta: ");
    fgets(s, BUFSIZ, stdin);

    s[strlen(s) - 1] = '\0';
    trasforma(s); // Trasformiamo str in minuscolo

    if (strcmp(domande[n].risposta, s) == 0) {
      printf("La risposta e\' corretta!\n");
      if (rispCorrette == 3) { // Se il concorrente dovesse aver indovinato tre domande può
               // passare in automatico al gioco successivo, dopo aver pescato
        return 0;
      }

      rispCorrette++;
    } else {
      err++;
      printf("Risposta sbagliata :(\n");
    }
    round++;
  } while (err <= 1 && round <= 4); // L'utente dopo aver commesso più di un
                                    // errore, o dopo aver superato i tre round

  if (err > 1) {
    return -1; // In questo caso l'utente viene squalificato e non può passare
               // al prossimo gioco
  }

  return 0;
}

void trasforma(char *str) {
  for (int i = 0; i < strlen(str); i++) {
    str[i] = tolower(str[i]);
  }
}

int num_casuale(int min, int max) {
  // Inizializza il generatore di numeri casuali con il tempo corrente
  srand(time(NULL));

  // Genera un numero casuale tra min e max (inclusi)
  return (rand() % (max - min + 1)) + min;
}

int pesca_a_sorpresa() {
  // Dichiarazione delle variabili
  int n = 0; // Numero generato casualmente che corrisponderà al premio
             // contenuto nel pidigozzo
  int nPidigozzi = 45; // Numero di pidigozzi presenti sul pidigozzaro (ruota
                       // contenente i tubicini con i premi)
  int monte_premi = 0;
  FILE *file;
  domanda d;
  char *riga;
  char s[BUFSIZ];

  printf("Benvenuto nella PESCA A SORPRESA!\nPronto ad aumentare il tuo "
         "montepremi?\n");
  n = num_casuale(1, nPidigozzi);

  switch (n) {
  case 1:
  case 11:
  case 17:
  case 23:
  case 27:
    printf("Hai pescato 10.000 €\n\n");
    monte_premi = 10000;
    break;

  case 2:
  case 22:
  case 34:
  case 36:
  case 37:
    printf("Hai pescato 20.000 €\n\n");
    monte_premi = 20000;
    break;

  case 26:
  case 31:
  case 39:
  case 42:
  case 44:
    printf("Hai pescato 25.000 €\n\n");
    monte_premi = 25000;
    break;

  case 3:
  case 6:
  case 12:
  case 18:
  case 40:
    printf("Hai pescato 30.000 €\n\n");
    monte_premi = 30000;
    break;

  case 4:
  case 8:
  case 16:
  case 32:
  case 41:
    printf("Hai pescato 40.000 €\n\n");
    monte_premi = 40000;
    break;

  case 5:
  case 10:
  case 20:
  case 25:
  case 30:
    printf("Hai pescato 50.000 €\n\n");
    monte_premi = 50000;
    break;

  case 7:
  case 14:
  case 21:
  case 28:
  case 35:
    printf("Hai pescato 75.000 €\n\n");
    monte_premi = 75000;
    break;

  case 15:
    printf("Hai pescato 150.000 €\n\n");
    monte_premi = 150000;
    break;

  case 9:
  case 24:
  case 33:
    printf("Hai pescato la Buona Sorte\n");
    file = fopen("domande_buonasorte.txt", "r");

    if (file == NULL) {
      printf("Errore nell'apertura del file.\n");
      return -1;
    }

    riga = leggiRiga("domande_buonasorte.txt", 1);
    riga[strlen(riga) - 1] = '\0';
    d.domanda = malloc(strlen(riga) * sizeof(char));
    strcpy(d.domanda, riga);

    riga = leggiRiga("domande_buonasorte.txt", 2);
    d.risposta = malloc(strlen(riga) * sizeof(char));
    strcpy(d.risposta, riga);

    fclose(file);

    printf("%s\n", d.domanda);
    printf("Scrivi qui la tua risposta: ");
    fgets(s, BUFSIZ, stdin);
    s[strlen(s) - 1] = '\0';
    trasforma(s);

    if (strcmp(d.risposta, s) == 0) {
      printf("\nPerfetto!!! Il tuo monte premi corrisponde a 150.000 €\n\n");
      monte_premi = 150000;
    } else {
      printf("Mi dispiace, hai perso! AVANTI UN ALTRO!\n");
      return -1;
    }
    break;

  case 13:
  case 29:
  case 43:
    printf("Hai pescato Lo Iettatore\n");
    file = fopen("domande_iettatore.txt", "r");

    if (file == NULL) {
      printf("Errore nell'apertura del file.\n");
      return -1;
    }

    riga = leggiRiga("domande_iettatore.txt", 1);
    riga[strlen(riga) - 1] = '\0';
    d.domanda = malloc(strlen(riga) * sizeof(char));
    strcpy(d.domanda, riga);

    riga = leggiRiga("domande_iettatore.txt", 2);
    d.risposta = malloc(strlen(riga) * sizeof(char));
    strcpy(d.risposta, riga);

    printf("%s\n", d.domanda);
    printf("Scrivi qui la tua risposta: ");
    fgets(s, BUFSIZ, stdin);
    s[strlen(s) - 1] = '\0';
    trasforma(s);

    if (strcmp(d.risposta, s) == 0) {
      printf("\nBravo! Ora riparti dalla tripletta!\n\n");
      tripletta();
    } else {
      printf("Mi dispiace, hai perso! AVANTI UN ALTRO!\n");
      return -1;
    }
    break;

  case 19:
  case 38:
  case 45:
    printf("Hai pescato AVANTI UN ALTRO!\n");
    return -1; // Ritorniamo nel main. Tocca ad un altro giocatore quindi quello
               // corrente viene squalificato
    break;
  }

  return monte_premi;
}

int gioco_finale(int monte_premi) {
  int nDomande = 21;
  int numRighe = 0;
  int err = 0;
  int controllo = 0;
  char fileDomande[] ="domande_finale.txt";
  char s[BUFSIZ];
  FILE * file;
  char * riga;
  char * str;
  domanda *domande;

  numRighe = contaRigheFile(fileDomande);

  domande = (domanda *) malloc(nDomande * sizeof(domanda));
  monte_premi += 100000;

  for (int i = 1, j = 2, y = 0; i <= numRighe; y++) {
    // Lettura della domanda dal file
    riga = leggiRiga(fileDomande, i);
    riga[strlen(riga) - 1] = '\0';
    domande[y].domanda = malloc(strlen(riga) * sizeof(char));
    strcpy(domande[y].domanda, riga);
    
    // Lettura delle opzioni e della risposta corretta dal file
    domande[y].opzioni = malloc(2 * sizeof(char *));
    riga = leggiRiga(fileDomande, j);
    str = strtok(riga, "-");
    domande[y].opzioni[0] = malloc(strlen(str) * sizeof(char));
    strcpy(domande[y].opzioni[0], str);

    str = strtok(NULL, "-");

    domande[y].opzioni[1] = malloc(strlen(str) * sizeof(char));
    strcpy(domande[y].opzioni[1], str);

    str = strtok(NULL, "-");
    
    domande[y].risposta = malloc(strlen(str) * sizeof(char));

    if(j != numRighe) {
      str[strlen(str) - 1] = '\0';
    }

    strcpy(domande[y].risposta, str);
    i += 2;
    j += 2;
  }

  
  for (int i = 0; i < nDomande && controllo == 0; i++) {
    printf("DOMANDA %d\n%s %s o %s\n",(i + 1), domande[i].domanda, domande[i].opzioni[0], domande[i].opzioni[1]);
    printf("Scrivi qui la tua risposta: ");   
    fgets(s, BUFSIZ, stdin);
    
    s[strlen(s) - 1] = '\0';
    trasforma(s);

    printf("La risposta che hai inserito e\': %s\nLa risposta corretta e\': %s", s, domande[i].risposta);
    
    if (strcmp(domande[i].risposta, s) != 0) {
      monte_premi -= 500;
      i = -1;
      printf("Hai sbagliato! Ricominciamo da capo\nIl tuo montepremi ora ammonota a: %d\n\n", monte_premi); 
    
      if (monte_premi == 30000) {
        controllo = 1;
      }
    } else {
      printf("\n\n");
    }
  }

  if (controllo == 1) {
    for (int i = 0; i < nDomande; i++) {
      printf("%s %s o %s\n", domande[i].domanda, domande[i].opzioni[0], domande[i].opzioni[1]);
      printf("Scrivi qui la tua risposta: ");   
      fgets(s, BUFSIZ, stdin);
      
      s[strlen(s) - 1] = '\0';
      trasforma(s);

      printf("La risposta che hai inserito e\': %s\nLa risposta corretta e\': %s", s, domande[i].risposta);
      
      if (strcmp(domande[i].risposta, s) != 0) {
        printf("Mi dispiace! Hai perso tutto il monte premi!\n");
      return 0;
      }
    }
  }
  
  return monte_premi;
}

void salvo(char * nome, int montepremi) {
  FILE * file;
  
  file = fopen("Classifica.txt", "a"); // Apre il file in modalità append

  if (file == NULL) {
    printf("Errore nell'apertura del file.\n");
    return;
  }

  fprintf(file, "\n%s %d", nome, montepremi);

  fclose(file);
}

void riordina(char * nome, int monte_premi) {
  // Dichiarazione delle funzioni
  void stampaVincitore(giocatore *, char *);
  void stampaClassifica(giocatore *);
  
  // Dichiarazione delle variabili
  int numRighe = 0;
  giocatore g; //Variabile d'appogio per il BubbleSort
  char * riga;
  char * str;
  FILE * file;
  giocatore * giocatori;
  
  file = fopen("Classifica.txt", "r");
  
  if (file == NULL) {
    printf("Errore nell'apertura del file.\n");
    return;
  }

  // Attraverso la funzione contaRigheFile contiamo da quante righe è composto il file
  numRighe = contaRigheFile("Classifica.txt");

  // Allochiamo la memoria necessaria nello heap per poter contenere tutti i giocatori presenti nel file
  giocatori = (giocatore *) malloc(numRighe * sizeof(giocatore));

  for (int i = 1; i <= numRighe; i++) { // Si parte da 1 perché nel file non esiste la riga 
    riga = leggiRiga("Classifica.txt", i);

    if (i != numRighe) {
      riga[strlen(riga) - 1] = '\0';
    }
    
    str = strtok(riga, " ");
    giocatori[i - 1].nome = malloc(strlen(str) * sizeof(char));
    strcpy(giocatori[i - 1].nome, str);
    
    str = strtok(NULL, " ");
    giocatori[i - 1].monte_premi = atoi(str);
  }

  fclose(file);
  
  // Ordiniamo l'array in ordine decrescente
  for (int i = 0; i < numRighe - 1; i++) {
    for (int j = i + 1; j < numRighe; j++) {
      if (giocatori[i].monte_premi < giocatori[j].monte_premi) {
        g = giocatori[i];
        giocatori[i] = giocatori[j];
        giocatori[j] = g;
      }
    }
  }
  stampaVincitore(giocatori, nome);
  stampaClassifica(giocatori);
}

void stampaVincitore(giocatore * giocatori, char * nome) {
  // Dichiarazione delle variabili
  int posizione = 1;
  int numRighe = 0;
  int controllo = 0; // Quando controllo è uguale a 0 vuol dire che non è stato trovato il giocatore, quando viene impostato ad 1 vuol dire che è stato trovato e si può uscire dal ciclo do while
  FILE * file;
  
  file = fopen("Classifica.txt", "r");

  if (file == NULL) {
    printf("Errore nell'apertura del file.\n");
    return;
  }

  numRighe = contaRigheFile("Classifica.txt");
  
  do {
    if(strcmp(nome, giocatori[posizione - 1].nome) == 0) {
      controllo = 1; 
    } else {
      posizione++;
    }
  } while(posizione <= numRighe && controllo != 1);
  
  printf("Sei arrivato alla posizione: %d\n", posizione);
  printf("Il primo della classifica e\' \"%s\" con un monte premi di: %d", giocatori[0].nome, giocatori[0].monte_premi);
  fclose(file);
}

void stampaClassifica(giocatore * giocatori) {
  // Dichiarazione delle variabili
  int numRighe = contaRigheFile("Classifica.txt");
  FILE * file;

  file = fopen("Classifica.txt", "w");

  if (file == NULL) {
    printf("Errore nell'apertura del file.\n");
    return;
  }
  
  for (int i = 0; i < numRighe; i++) {
    fprintf(file, "%s %d", giocatori[i].nome, giocatori[i].monte_premi);
    
    if (i != (numRighe - 1)) {
      fprintf(file, "\n");
    }
  }
}

int contaRigheFile(char *nomeFile) {
  FILE *file;
  char riga[BUFSIZ];
  int numRighe = 0;

  file = fopen(nomeFile, "r");

  // Verifica se il file è stato aperto correttamente
  if (file == NULL) {
    printf("Impossibile aprire il file.\n");
    return 0; // Ritorna 0 se dovessero esserci problemi nell'apertura del file
  }

  // Legge il file carattere per carattere
  while (fgets(riga, BUFSIZ, file) != NULL) {
    numRighe++;
  }

  // Chiudi il file
  fclose(file);
  return numRighe;
}